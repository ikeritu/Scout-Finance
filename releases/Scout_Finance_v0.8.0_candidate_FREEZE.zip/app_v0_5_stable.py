"""
Streamlit app.

Private MVP interface for the equity research assistant.

Current scope:
- Password-protected private interface.
- Demo/real mode selector.
- Run quantitative pipeline.
- View latest run summary.
- View final research table:
    signals + market_snapshots + OpenAI placeholder + manual feedback.
- Fast filters for the final research table.
- Cleaner labels for categories and feedback.
- Individual company detail card with score breakdown.
- Quick feedback from the company detail card.
- Feedback history by ticker.
- Inline FAQ panel in the top-right area.
- Visual dashboard with basic charts.
- Direct CSV/Excel download buttons.
- Estimated OpenAI run cost based on .env variables.
- Persist placeholder OpenAI analysis when ENABLE_OPENAI=false.
- Add manual feedback by ticker.
- Export CSV/Excel using existing export module.

Not included in this phase:
- Real OpenAI API calls.
- Broker integration.
- Trading recommendations.
- Portfolio simulation.
- Advanced charts.
- Multi-user roles.
"""

from __future__ import annotations

import base64
import io
import json
import os
import traceback
import textwrap
from pathlib import Path
from datetime import datetime
from typing import Any

import pandas as pd
import streamlit as st

from src.auth import get_auth_status, validate_password
from src.export import export_default_bundle
from src.feedback import add_manual_feedback_by_ticker, get_valid_feedback_labels
from src.openai_client import get_openai_status
from src.openai_persistence import load_openai_analysis, persist_placeholder_analysis_for_top_signals
from src.pipeline import run_quant_pipeline
from src.analysis_history import (
    build_analysis_comparison_df,
    build_display_comparison_df,
    export_comparison_csv_bytes,
    summarize_analysis_history,
)
from src.results import (
    get_latest_run_id,
    get_run_summary,
    get_top_final_research_view,
    list_runs,
    load_cost_log,
    load_manual_feedback,
    summarize_final_research_view,
)


APP_TITLE = "Scout Finance — Private Research MVP"
DEFAULT_TOP_N = 20


CATEGORY_LABELS = {
    "high_priority_research": "Alta prioridad",
    "medium_priority_research": "Media prioridad",
    "watchlist": "Watchlist",
    "low_priority": "Baja prioridad",
    "low_confidence": "Baja confianza",
    "high_risk_review": "Revisar riesgo",
    "excluded": "Excluida",
}


FEEDBACK_LABELS = {
    "interesting": "Interesante",
    "discard": "Descartar",
    "review_later": "Revisar después",
    "false_positive": "Falso positivo",
    "needs_more_research": "Investigar más",
    "already_known": "Ya conocida",
}



# Stable release label: Scout Finance v0.4 — Phase 4H docs + FAQ
st.set_page_config(
    page_title=APP_TITLE,
    page_icon="📊",
    layout="wide",
)


def _init_session_state() -> None:
    """
    Initialize Streamlit session state values.
    """

    if "authenticated" not in st.session_state:
        st.session_state.authenticated = False

    if "show_faq" not in st.session_state:
        st.session_state.show_faq = False


def _render_login() -> None:
    """
    Render password login screen.
    """

    st.title("📊 Scout Finance")
    st.caption("Private Research MVP — acceso protegido")

    auth_status = get_auth_status()

    if not auth_status["app_password_defined"]:
        st.error("APP_PASSWORD no está definido en .env.")
        st.stop()

    if auth_status["uses_default_password"]:
        st.warning("APP_PASSWORD sigue usando el valor por defecto. Cámbialo en .env.")

    password = st.text_input("Contraseña", type="password")

    if st.button("Entrar"):
        if validate_password(password):
            st.session_state.authenticated = True
            st.rerun()
        else:
            st.error("Contraseña incorrecta.")

    st.stop()


def _safe_run_action(action_name: str, func, *args, **kwargs):
    """
    Execute an action and show errors in Streamlit without hiding details.
    """

    try:
        return func(*args, **kwargs)
    except Exception as exc:
        st.error(f"Error ejecutando {action_name}: {exc}")
        with st.expander("Ver detalle técnico"):
            st.code(traceback.format_exc())
        return None


def _is_missing(value: Any) -> bool:
    """
    Return True if a value should be treated as missing.
    """

    if value is None:
        return True

    try:
        if pd.isna(value):
            return True
    except TypeError:
        pass

    if isinstance(value, str) and value.strip() == "":
        return True

    return False


def _display_text(value: Any, default: str = "—") -> str:
    """
    Convert values to display text.
    """

    if _is_missing(value):
        return default

    return str(value)


def _format_number(value: Any, decimals: int = 2) -> str:
    """
    Format numbers for display.
    """

    if _is_missing(value):
        return "—"

    try:
        return f"{float(value):,.{decimals}f}"
    except (TypeError, ValueError):
        return str(value)


def _format_compact_usd(value: Any) -> str:
    """
    Format large USD values compactly.
    """

    if _is_missing(value):
        return "—"

    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)

    abs_number = abs(number)

    if abs_number >= 1_000_000_000_000:
        return f"${number / 1_000_000_000_000:.2f}T"

    if abs_number >= 1_000_000_000:
        return f"${number / 1_000_000_000:.2f}B"

    if abs_number >= 1_000_000:
        return f"${number / 1_000_000:.2f}M"

    return f"${number:,.2f}"


def _format_percent_ratio(value: Any) -> str:
    """
    Format ratio as percentage.
    """

    if _is_missing(value):
        return "—"

    try:
        return f"{float(value) * 100:.2f}%"
    except (TypeError, ValueError):
        return str(value)


def _category_label(value: Any) -> str:
    """
    Convert internal category to user-facing label.
    """

    if _is_missing(value):
        return "—"

    value_str = str(value)
    return CATEGORY_LABELS.get(value_str, value_str)


def _feedback_label(value: Any) -> str:
    """
    Convert internal feedback label to user-facing label.
    """

    if _is_missing(value):
        return "—"

    value_str = str(value)
    return FEEDBACK_LABELS.get(value_str, value_str)


def _short_openai_reason(value: Any) -> str:
    """
    Shorten technical OpenAI placeholder messages for UI display.
    """

    if _is_missing(value):
        return "—"

    value_str = str(value)

    if "ENABLE_OPENAI=false" in value_str:
        return "IA desactivada"

    if len(value_str) > 80:
        return value_str[:77] + "..."

    return value_str



def _env_float(name: str, default: float) -> float:
    """
    Read a float from environment variables.
    """

    value = os.getenv(name)

    if value is None or value.strip() == "":
        return default

    try:
        return float(value)
    except ValueError:
        return default


def _estimate_openai_run_cost(number_of_companies: int) -> dict[str, float]:
    """
    Estimate OpenAI cost for one run based on number of companies.

    Values are configurable through .env:

    OPENAI_EST_INPUT_TOKENS_PER_COMPANY
    OPENAI_EST_OUTPUT_TOKENS_PER_COMPANY
    OPENAI_INPUT_COST_PER_1M
    OPENAI_OUTPUT_COST_PER_1M

    Costs are not hardcoded because provider prices can change.
    """

    input_tokens_per_company = _env_float(
        "OPENAI_EST_INPUT_TOKENS_PER_COMPANY",
        3000.0,
    )
    output_tokens_per_company = _env_float(
        "OPENAI_EST_OUTPUT_TOKENS_PER_COMPANY",
        1200.0,
    )
    input_cost_per_1m = _env_float(
        "OPENAI_INPUT_COST_PER_1M",
        0.0,
    )
    output_cost_per_1m = _env_float(
        "OPENAI_OUTPUT_COST_PER_1M",
        0.0,
    )

    estimated_input_tokens = number_of_companies * input_tokens_per_company
    estimated_output_tokens = number_of_companies * output_tokens_per_company

    estimated_input_cost = (estimated_input_tokens / 1_000_000) * input_cost_per_1m
    estimated_output_cost = (estimated_output_tokens / 1_000_000) * output_cost_per_1m
    estimated_total_cost = estimated_input_cost + estimated_output_cost

    return {
        "number_of_companies": float(number_of_companies),
        "input_tokens_per_company": float(input_tokens_per_company),
        "output_tokens_per_company": float(output_tokens_per_company),
        "estimated_input_tokens": float(estimated_input_tokens),
        "estimated_output_tokens": float(estimated_output_tokens),
        "input_cost_per_1m": float(input_cost_per_1m),
        "output_cost_per_1m": float(output_cost_per_1m),
        "estimated_total_cost": float(estimated_total_cost),
    }



def _quant_reason_label(value: Any) -> str:
    """
    Translate quantitative reason tokens to plain Spanish.
    """

    if _is_missing(value):
        return "—"

    translations = {
        "strong_relative_volume": "Volumen relativo fuerte",
        "positive_momentum": "Buen momentum reciente",
        "good_liquidity": "Buena liquidez",
        "constructive_price_context": "Contexto técnico favorable",
        "elevated_risk": "Riesgo elevado",
        "high_data_confidence": "Datos con alta confianza",
        "no_strong_quant_signal": "Sin señal cuantitativa fuerte",
    }

    tokens = [token.strip() for token in str(value).split(";") if token.strip()]
    labels = [translations.get(token, token) for token in tokens]

    return " · ".join(labels) if labels else "—"


def _score_help_text() -> str:
    """
    Return plain-language score explanation.
    """

    return (
        "El score no es una recomendación de compra. Es una prioridad de revisión. "
        "Cuanto más alto, más merece la pena investigar esa empresa según datos "
        "cuantitativos como volumen, momentum, liquidez, contexto técnico y calidad de datos."
    )


def _render_cost_env_help() -> None:
    """
    Render .env help for OpenAI cost estimation.
    """

    with st.sidebar.expander("Configurar precios .env"):
        st.caption("Para que el coste estimado/run no salga a cero, añade precios por 1M tokens.")
        st.code(
            "OPENAI_EST_INPUT_TOKENS_PER_COMPANY=3000\n"
            "OPENAI_EST_OUTPUT_TOKENS_PER_COMPANY=1200\n"
            "OPENAI_INPUT_COST_PER_1M=0\n"
            "OPENAI_OUTPUT_COST_PER_1M=0",
            language="env",
        )


def _render_faq_main() -> None:
    """
    Render a very plain-language FAQ in the main content area.

    Phase 4H:
    Updated FAQ for the stable v0.4 workflow.
    """

    st.title("❓ FAQ para dummies")
    st.caption("Guía sencilla para entender Scout Finance v0.4 estable.")

    if st.button("← Volver a la herramienta", use_container_width=False):
        st.session_state.show_faq = False
        st.rerun()

    st.markdown(
        """
---

# 🧠 1. Qué es Scout Finance

Scout Finance es una herramienta privada para **priorizar empresas investigables**.

No es una app de trading.  
No es un asesor financiero.  
No recomienda comprar, vender ni mantener.  
No se conecta a brokers.

Su objetivo es ayudarte a responder:

> “¿Qué empresas merece la pena revisar primero y por qué?”

---

# 🧭 2. Flujo recomendado

El flujo normal es:

1. Ejecutar el pipeline cuantitativo.
2. Revisar el ranking.
3. Abrir una ficha individual.
4. Generar o consultar outputs Fase 2.
5. Comparar empresas usando JSON.
6. Revisar histórico por ticker.
7. Registrar feedback manual.

Dicho fácil:

> Primero detectas candidatas, luego investigas, comparas, guardas histórico y decides qué revisar con más calma.

---

# 🏠 3. Dashboard

El Dashboard es la pantalla de inicio.

Sirve para ver rápido:

- Mejor candidata a revisar.
- Empresas con análisis IA.
- Outputs Fase 2 generados.
- Empresas con datos insuficientes.
- Confianza media.
- Riesgo medio.
- Coste IA acumulado.
- Próxima acción recomendada.

No toma decisiones por ti. Solo resume el estado del radar.

---

# 🔎 4. Ranking

La pestaña Ranking muestra la lista de empresas priorizadas por el sistema cuantitativo.

El score no significa “comprar”.  
Significa:

> “Prioridad de revisión.”

Una empresa con score alto merece más atención, pero puede estar cara, tener riesgos o datos insuficientes.

---

# 📄 5. Análisis empresa

La pestaña Análisis empresa sirve para revisar una compañía concreta.

Incluye:

- Ficha cuantitativa.
- Estado IA legacy resumido.
- Outputs estructurados Fase 2.
- Scorecard PNG.
- Escenarios PNG.
- Informe Markdown.
- JSON estructurado.
- HTML ejecutivo.
- Feedback manual.

La parte más importante ahora es **Fase 2**, porque genera una salida reutilizable y comparable.

---

# 🧱 6. Qué es Fase 2

Fase 2 convierte el análisis en archivos estructurados:

```text
outputs/analyses/TICKER_FECHA.md
outputs/analyses/TICKER_FECHA.json
outputs/analyses/TICKER_FECHA_scorecard.png
outputs/analyses/TICKER_FECHA_scenarios.png
outputs/analyses/TICKER_FECHA_executive_card.html
```

El JSON es la pieza clave porque permite:

- Comparar empresas.
- Crear históricos.
- Generar visualizaciones.
- Detectar cambios de categoría.
- Reutilizar el análisis en portfolio o documentación.

---

# 🧮 7. Comparar empresas

La pestaña Comparar empresas lee los JSON ya generados.

No llama a OpenAI.  
No gasta tokens.

Sirve para comparar de un vistazo:

- Categoría final.
- Confianza.
- Riesgo.
- Calidad del negocio.
- Moat.
- Evidencia.
- Avisos de fuentes.
- Limitaciones.

También muestra rankings rápidos:

- Mayor confianza.
- Menor riesgo.
- Mejor calidad negocio.

---

# 📈 8. Histórico / técnico

La pestaña Histórico / técnico permite ver cómo cambia una empresa con el tiempo.

Si tienes varios JSON para el mismo ticker, puedes ver:

- Cambios de confianza.
- Cambios de riesgo.
- Cambios de calidad de negocio.
- Cambios de moat.
- Cambios de categoría.
- Evolución de scores.
- Evolución separada del riesgo.

Importante:

> En riesgo, más bajo es mejor.

Por eso el gráfico de riesgo va separado.

---

# ⚙️ 9. Ajustes / panel técnico

La pestaña Ajustes sirve para comprobar si el sistema está preparado.

Muestra:

- Estado general.
- OpenAI activo: Sí/No.
- API key definida: Sí/No.
- Modelo ligero.
- Modelo fuerte.
- Coste estimado por run.
- Presupuesto diario.
- Presupuesto mensual.
- Rutas de outputs.
- Últimos archivos generados.
- Checks rápidos del sistema.

No ejecuta OpenAI.  
No modifica archivos.

---

# 💰 10. Control de costes

Scout Finance estima coste antes de ejecutar análisis IA.

Conceptos básicos:

- Tokens de entrada: texto que enviamos al modelo.
- Tokens de salida: respuesta generada por el modelo.
- Empresas IA/run: número máximo de empresas que se analizarán en una ejecución.
- Coste estimado/run: coste aproximado según configuración.

Recomendación:

> Para pruebas reales, empieza siempre con pocas empresas.

---

# 🧠 11. Qué significa confianza

La confianza mide cuánto puedes fiarte del análisis generado.

Puede bajar si:

- Faltan fuentes.
- Hay datos antiguos.
- Hay demasiadas suposiciones.
- Hay limitaciones de datos.
- La evidencia es débil.

Una categoría positiva con confianza baja debe leerse con prudencia.

---

# ⚠️ 12. Qué significa datos insuficientes

“Datos insuficientes” no significa que la empresa sea mala.

Significa:

> “Con la información disponible, no se puede comparar con solidez.”

En ese caso conviene revisar fuentes, fundamentales y contexto antes de sacar conclusiones.

---

# 🏷️ 13. Categorías internas permitidas

Scout Finance no usa Buy/Hold/Sell.

Usa categorías internas de seguimiento:

- 🟢 Alta calidad / seguir de cerca
- 🔵 Interesante pero cara
- 🟡 Apta solo con margen de seguridad
- 🟠 Riesgo elevado
- 🔴 Descartar por ahora
- ⚫ Datos insuficientes

Estas categorías no son recomendaciones de inversión.

---

# 🧾 14. Outputs generados

Los outputs principales son:

| Archivo | Para qué sirve |
|---|---|
| `.md` | Leer el informe completo |
| `.json` | Comparar, guardar histórico y reutilizar datos |
| `_scorecard.png` | Ver scores visualmente |
| `_scenarios.png` | Ver escenarios alcista/base/bajista |
| `_executive_card.html` | Ficha visual para abrir en navegador |

---

# 🛠️ 15. Checker de estabilidad

La Fase 4G añadió un checker:

```powershell
./.venv/Scripts/python.exe check_phase4g_stability.py
```

Sirve para comprobar:

- Que `app.py` existe.
- Que compila.
- Que las funciones principales siguen presentes.
- Que las pestañas principales siguen en la app.
- Que existe `outputs/analyses`.
- Que hay JSON para comparativa e histórico.

No llama a OpenAI.  
No modifica archivos.

---

# ❌ 16. Qué NO hace Scout Finance

Scout Finance no:

- Recomienda comprar acciones.
- Recomienda vender acciones.
- Dice cuánto invertir.
- Ejecuta órdenes.
- Se conecta a brokers.
- Garantiza rentabilidad.
- Sustituye asesoramiento financiero.
- Sustituye tu criterio.

Su función es:

> “Ayudarte a investigar mejor y con más orden.”

---

# ✅ 17. Estado estable v0.4

La versión estable actual incluye:

- Dashboard ejecutivo.
- Ranking resumido.
- Ficha individual.
- Outputs Fase 2.
- Comparativa visual.
- Histórico por empresa.
- Ajustes / panel técnico.
- Checker de estabilidad.
- FAQ actualizado.

Es una base estable para seguir evolucionando sin romper lo que ya funciona.

---

# 🧩 18. Traducción rápida

| Término | Significado fácil |
|---|---|
| Ticker | Código bursátil de la empresa |
| Run | Ejecución del sistema |
| Score | Prioridad de revisión |
| JSON | Archivo estructurado reutilizable |
| Markdown | Informe en texto |
| Scorecard | Resumen visual de puntuaciones |
| Moat | Ventaja competitiva |
| Riesgo | 0 bajo, 10 alto |
| Confianza | Fiabilidad del análisis |
| Pipeline | Proceso automático |
| Feedback | Tu revisión manual |
"""
    )




def _render_sidebar() -> tuple[str, int]:
    """
    Render sidebar controls.
    """

    if st.sidebar.button("❓ FAQ para dummies", use_container_width=True):
        st.session_state.show_faq = not st.session_state.show_faq
        st.rerun()

    st.sidebar.divider()

    st.sidebar.title("⚙️ Configuración")

    mode = st.sidebar.selectbox(
        "Modo",
        options=["demo", "real"],
        index=0,
        help="demo usa data/demo; real usa data/real.",
    )

    top_n = st.sidebar.slider(
        "Número de empresas a cargar",
        min_value=5,
        max_value=50,
        value=DEFAULT_TOP_N,
        step=5,
    )

    st.sidebar.divider()

    openai_status = get_openai_status()
    st.sidebar.subheader("OpenAI")
    st.sidebar.write(f"Activado: `{openai_status['enable_openai']}`")
    st.sidebar.write(f"Modelo ligero: `{openai_status['model_light']}`")

    estimated_cost = _estimate_openai_run_cost(
        int(openai_status["max_companies_per_run"])
    )

    st.sidebar.markdown("### 💰 Control de costes OpenAI")
    st.sidebar.write(f"Empresas IA/run: `{int(estimated_cost['number_of_companies'])}`")
    st.sidebar.write(
        f"Tokens estimados/run: "
        f"`{int(estimated_cost['estimated_input_tokens']):,}` entrada + "
        f"`{int(estimated_cost['estimated_output_tokens']):,}` salida"
    )
    st.sidebar.write(
        f"Coste estimado/run: "
        f"`${estimated_cost['estimated_total_cost']:.4f}`"
    )
    st.sidebar.write(f"Presupuesto diario: `${openai_status['daily_budget_usd']:.2f}`")
    st.sidebar.write(f"Presupuesto mensual: `${openai_status['monthly_budget_usd']:.2f}`")

    if (
        estimated_cost["input_cost_per_1m"] == 0
        and estimated_cost["output_cost_per_1m"] == 0
    ):
        st.sidebar.caption(
            "Define OPENAI_INPUT_COST_PER_1M y OPENAI_OUTPUT_COST_PER_1M "
            "en .env para estimar coste real."
        )

    _render_cost_env_help()

    st.sidebar.divider()

    if st.sidebar.button("Cerrar sesión"):
        st.session_state.authenticated = False
        st.rerun()

    return mode, top_n


def _render_run_controls(mode: str) -> None:
    """
    Render execution controls.
    """

    st.subheader("🚀 Ejecución")

    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("Ejecutar pipeline cuantitativo", use_container_width=True):
            with st.spinner("Ejecutando pipeline cuantitativo..."):
                summary = _safe_run_action(
                    "pipeline cuantitativo",
                    run_quant_pipeline,
                    mode=mode,
                    period="1y",
                    only_passed_signals=True,
                )

            if summary:
                st.success(f"Pipeline completado. Run ID: {summary['run_id']}")

    with col2:
        top_n_openai = st.number_input(
            "Top N placeholder OpenAI",
            min_value=1,
            max_value=5,
            value=3,
            step=1,
            help="Respeta MAX_OPENAI_COMPANIES_PER_RUN.",
        )

        if st.button("Persistir análisis OpenAI placeholder", use_container_width=True):
            latest_run_id = get_latest_run_id(mode=mode)

            if latest_run_id is None:
                st.warning("No hay runs. Ejecuta primero el pipeline.")
            else:
                with st.spinner("Persistiendo análisis placeholder..."):
                    summary = _safe_run_action(
                        "OpenAI placeholder",
                        persist_placeholder_analysis_for_top_signals,
                        run_id=latest_run_id,
                        mode=mode,
                        top_n=int(top_n_openai),
                        use_strong_model=False,
                        write_cost_log=True,
                    )

                if summary:
                    st.success(
                        "Análisis placeholder guardado: "
                        f"{summary['analysis_rows_inserted']} filas."
                    )

    with col3:
        if st.button("Exportar bundle CSV/Excel", use_container_width=True):
            latest_run_id = get_latest_run_id(mode=mode)

            if latest_run_id is None:
                st.warning("No hay runs para exportar.")
            else:
                with st.spinner("Exportando archivos..."):
                    exported = _safe_run_action(
                        "exportación",
                        export_default_bundle,
                        run_id=latest_run_id,
                        mode=mode,
                        top_n=20,
                        include_excel=True,
                    )

                if exported:
                    st.success("Exportación completada.")
                    for name, path in exported.items():
                        st.write(f"- **{name}**: `{path}`")


def _get_feedback_count_from_final_view(mode: str, top_n: int = 500) -> int:
    """
    Count manual feedback rows visible in the final research view.
    """

    latest_run_id = get_latest_run_id(mode=mode)

    if latest_run_id is None:
        return 0

    final_df = get_top_final_research_view(
        run_id=latest_run_id,
        mode=mode,
        top_n=top_n,
        include_excluded=True,
    )

    if final_df.empty or "feedback_id" not in final_df.columns:
        return 0

    return int(final_df["feedback_id"].notna().sum())


def _render_run_summary(mode: str) -> None:
    """
    Render latest run summary and recent runs.
    """

    st.subheader("📌 Última ejecución")

    latest_run_id = get_latest_run_id(mode=mode)

    if latest_run_id is None:
        st.info("Todavía no hay ejecuciones. Ejecuta el pipeline cuantitativo.")
        return

    summary = get_run_summary(run_id=latest_run_id, mode=mode)
    feedback_count = _get_feedback_count_from_final_view(mode=mode)

    col1, col2, col3, col4, col5 = st.columns(5)

    col1.metric("Empresas válidas", summary.get("valid_companies", 0))
    col2.metric("Signals", summary.get("signals_rows", 0))
    col3.metric("OpenAI rows", summary.get("openai_analysis_rows", 0))
    col4.metric("Feedback manual", feedback_count)
    col5.metric("Errores datos", summary.get("data_errors_rows", 0))

    with st.expander("Ver resumen técnico del run"):
        st.json(summary)

    st.subheader("🕘 Runs recientes")
    runs_df = list_runs(mode=mode, limit=10)

    if runs_df.empty:
        st.info("No hay runs recientes.")
    else:
        st.dataframe(runs_df, use_container_width=True, hide_index=True)


def _apply_final_view_filters(final_df: pd.DataFrame) -> pd.DataFrame:
    """
    Render and apply fast filters for final research view.
    """

    if final_df.empty:
        return final_df

    st.markdown("#### Filtros rápidos")

    col1, col2, col3, col4, col5 = st.columns(5)

    filtered_df = final_df.copy()

    with col1:
        sectors = sorted(
            filtered_df["sector"].dropna().astype(str).unique().tolist()
        ) if "sector" in filtered_df.columns else []
        selected_sectors = st.multiselect(
            "Sector",
            options=sectors,
            default=[],
            placeholder="Todos",
        )

    with col2:
        if "category_final" in filtered_df.columns:
            category_values = sorted(
                filtered_df["category_final"].dropna().astype(str).unique().tolist()
            )
            category_options = {
                _category_label(value): value for value in category_values
            }
        else:
            category_options = {}

        selected_category_labels = st.multiselect(
            "Categoría",
            options=list(category_options.keys()),
            default=[],
            placeholder="Todas",
        )

    with col3:
        openai_filter = st.selectbox(
            "OpenAI",
            options=["Todas", "Con análisis", "Sin análisis"],
            index=0,
        )

    with col4:
        feedback_filter = st.selectbox(
            "Feedback",
            options=["Todas", "Con feedback", "Sin feedback"],
            index=0,
        )

    with col5:
        min_score = st.number_input(
            "Score mínimo",
            min_value=0.0,
            max_value=100.0,
            value=0.0,
            step=5.0,
        )

    if selected_sectors and "sector" in filtered_df.columns:
        filtered_df = filtered_df[filtered_df["sector"].isin(selected_sectors)]

    if selected_category_labels and "category_final" in filtered_df.columns:
        selected_category_values = [
            category_options[label] for label in selected_category_labels
        ]
        filtered_df = filtered_df[filtered_df["category_final"].isin(selected_category_values)]

    if openai_filter == "Con análisis" and "openai_analysis_id" in filtered_df.columns:
        filtered_df = filtered_df[filtered_df["openai_analysis_id"].notna()]
    elif openai_filter == "Sin análisis" and "openai_analysis_id" in filtered_df.columns:
        filtered_df = filtered_df[filtered_df["openai_analysis_id"].isna()]

    if feedback_filter == "Con feedback" and "feedback_id" in filtered_df.columns:
        filtered_df = filtered_df[filtered_df["feedback_id"].notna()]
    elif feedback_filter == "Sin feedback" and "feedback_id" in filtered_df.columns:
        filtered_df = filtered_df[filtered_df["feedback_id"].isna()]

    if "score_priority" in filtered_df.columns:
        filtered_df = filtered_df[filtered_df["score_priority"] >= min_score]

    filtered_df = filtered_df.sort_values(
        by=["score_priority", "score_confidence"],
        ascending=[False, False],
    ).reset_index(drop=True)

    return filtered_df


def _build_display_final_view(final_df: pd.DataFrame) -> pd.DataFrame:
    """
    Build a cleaner dataframe for the main UI table.
    """

    if final_df.empty:
        return final_df

    ranked_df = final_df.copy().reset_index(drop=True)
    ranked_df.insert(0, "rank", ranked_df.index + 1)

    display_df = pd.DataFrame()

    mappings = {
        "rank": "Rank",
        "ticker": "Ticker",
        "company_name": "Empresa",
        "sector": "Sector",
        "industry": "Industria",
        "score_priority": "Score",
        "category_final": "Categoría",
        "price_at_signal": "Precio",
        "market_cap": "Market Cap",
        "relative_volume": "Vol. Rel.",
        "change_5d": "5D",
        "change_20d": "20D",
        "openai_model": "Modelo IA",
        "openai_reason_to_pass": "Estado IA",
        "feedback_label": "Feedback",
        "reviewed_by": "Revisado por",
    }

    for original, renamed in mappings.items():
        if original in ranked_df.columns:
            display_df[renamed] = ranked_df[original]

    if "Score" in display_df.columns:
        display_df["Score"] = display_df["Score"].apply(lambda value: _format_number(value, 2))

    if "Precio" in display_df.columns:
        display_df["Precio"] = display_df["Precio"].apply(lambda value: _format_number(value, 2))

    if "Market Cap" in display_df.columns:
        display_df["Market Cap"] = display_df["Market Cap"].apply(_format_compact_usd)

    if "Vol. Rel." in display_df.columns:
        display_df["Vol. Rel."] = display_df["Vol. Rel."].apply(lambda value: _format_number(value, 2))

    if "5D" in display_df.columns:
        display_df["5D"] = display_df["5D"].apply(_format_percent_ratio)

    if "20D" in display_df.columns:
        display_df["20D"] = display_df["20D"].apply(_format_percent_ratio)

    if "Categoría" in display_df.columns:
        display_df["Categoría"] = display_df["Categoría"].apply(_category_label)

    if "Feedback" in display_df.columns:
        display_df["Feedback"] = display_df["Feedback"].apply(_feedback_label)

    if "Estado IA" in display_df.columns:
        display_df["Estado IA"] = display_df["Estado IA"].apply(_short_openai_reason)

    display_df = display_df.fillna("")

    return display_df



def _parse_raw_response_json(value: Any) -> dict[str, Any] | None:
    """
    Parse raw_response_json safely.

    Returns None when the value is empty, invalid or not a JSON object.
    """

    if _is_missing(value):
        return None

    if isinstance(value, dict):
        return value

    try:
        parsed = json.loads(str(value))
    except (json.JSONDecodeError, TypeError, ValueError):
        return None

    if not isinstance(parsed, dict):
        return None

    return parsed


def _get_latest_company_report_v2(
    ticker: str,
    run_id: str | None,
    mode: str,
) -> dict[str, Any] | None:
    """
    Load the latest valid Company Research Report v0.2 for one ticker.

    Priority:
    - Same run.
    - Same ticker.
    - schema_version == company_report_v0.2.
    - Latest id first.
    """

    if run_id is None:
        return None

    analysis_df = load_openai_analysis(run_id=run_id, mode=mode)

    if analysis_df.empty:
        return None

    required_columns = {"ticker", "schema_version", "raw_response_json"}

    if not required_columns.issubset(set(analysis_df.columns)):
        return None

    ticker_df = analysis_df[
        (analysis_df["ticker"].astype(str) == str(ticker))
        & (analysis_df["schema_version"].astype(str) == "company_report_v0.2")
    ].copy()

    if ticker_df.empty:
        return None

    if "id" in ticker_df.columns:
        ticker_df = ticker_df.sort_values("id", ascending=False)

    for _, analysis_row in ticker_df.iterrows():
        report = _parse_raw_response_json(analysis_row.get("raw_response_json"))

        if report is None:
            continue

        if report.get("markdown_report"):
            report["_analysis_id"] = analysis_row.get("id")
            report["_input_tokens"] = analysis_row.get("input_tokens")
            report["_output_tokens"] = analysis_row.get("output_tokens")
            report["_estimated_cost"] = analysis_row.get("estimated_cost")
            report["_model"] = analysis_row.get("model")
            report["_created_at"] = analysis_row.get("created_at")
            return report

    return None


def _format_score_or_dash(value: Any) -> str:
    """
    Format structured report scores.
    """

    if _is_missing(value):
        return "—"

    try:
        return f"{float(value):.0f}/100"
    except (TypeError, ValueError):
        return str(value)


def _render_list_items(title: str, values: Any) -> None:
    """
    Render a list in a compact and readable way.
    """

    st.write(f"**{title}**")

    if not isinstance(values, list) or not values:
        st.caption("Sin datos disponibles.")
        return

    for item in values:
        st.write(f"- {item}")



def _inject_legacy_report_styles() -> None:
    """
    CSS fixes for legacy Company Research Report v0.2.
    """

    st.markdown(
        """
        <style>
        .sf-legacy-card {
            border: 1px solid #e5e7eb;
            border-radius: 18px;
            padding: 18px 20px;
            background: #ffffff;
            margin: 10px 0 16px 0;
        }
        .sf-legacy-title {
            font-size: 1.15rem;
            font-weight: 800;
            color: #0f172a;
            margin-bottom: 14px;
        }
        .sf-legacy-grid {
            display: grid;
            grid-template-columns: minmax(300px, 2fr) repeat(3, minmax(130px, 1fr));
            gap: 14px;
            align-items: start;
        }
        .sf-legacy-label {
            color: #475569;
            font-size: 0.78rem;
            margin-bottom: 6px;
        }
        .sf-legacy-value {
            color: #0f172a;
            font-size: 1.05rem;
            font-weight: 750;
            line-height: 1.25;
            white-space: normal;
            overflow-wrap: anywhere;
        }
        .sf-legacy-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border-radius: 999px;
            padding: 9px 13px;
            background: #ecfdf5;
            border: 1px solid #bbf7d0;
            color: #166534;
            font-weight: 800;
            max-width: 100%;
            white-space: normal;
        }
        .sf-legacy-small {
            color: #64748b;
            font-size: 0.8rem;
            margin-top: 12px;
        }
        .sf-legacy-markdown {
            border: 1px solid #e5e7eb;
            border-radius: 18px;
            background: #ffffff;
            padding: 18px 20px;
            max-height: 720px;
            overflow-y: auto;
        }
        .sf-legacy-markdown h1 {
            font-size: 1.55rem !important;
            line-height: 1.25 !important;
            margin-top: 0.4rem !important;
            margin-bottom: 0.8rem !important;
        }
        .sf-legacy-markdown h2 {
            font-size: 1.22rem !important;
            line-height: 1.3 !important;
            margin-top: 1.0rem !important;
            margin-bottom: 0.45rem !important;
        }
        .sf-legacy-markdown h3 {
            font-size: 1.05rem !important;
            line-height: 1.3 !important;
            margin-top: 0.8rem !important;
            margin-bottom: 0.35rem !important;
        }
        .sf-legacy-markdown p,
        .sf-legacy-markdown li {
            font-size: 0.92rem !important;
            line-height: 1.55 !important;
        }
        @media (max-width: 950px) {
            .sf-legacy-grid {
                grid-template-columns: 1fr;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _legacy_category_badge(category: Any) -> str:
    """
    Return readable legacy category badge HTML.
    """

    text = _display_text(category)

    if text == "—":
        return "—"

    return f'<span class="sf-legacy-badge">🟢 {text}</span>'


def _render_compact_legacy_markdown(markdown_text: str) -> None:
    """
    Render legacy markdown with smaller visual scale.
    """

    st.markdown('<div class="sf-legacy-markdown">', unsafe_allow_html=True)
    st.markdown(markdown_text)
    st.markdown("</div>", unsafe_allow_html=True)


def _render_company_research_report_v2(report: dict[str, Any] | None) -> None:
    """
    Render legacy Company Research Report v0.2 inside the company detail card.

    This block is intentionally secondary to Phase 2 outputs.
    """

    _inject_legacy_report_styles()

    if report is None:
        st.info(
            "No hay todavía un Company Research Report v0.2 válido para esta empresa. "
            "Ejecuta `python -m src.company_research_report` para generarlo."
        )
        return

    model_name = report.get("_model") or report.get("model_used")
    estimated_cost = report.get("_estimated_cost") or report.get("estimated_cost_usd") or 0

    st.markdown(
        f"""
        <div class="sf-legacy-card">
            <div class="sf-legacy-title">📘 Company Research Report v0.2</div>
            <div class="sf-legacy-grid">
                <div>
                    <div class="sf-legacy-label">Categoría final</div>
                    <div class="sf-legacy-value">{_legacy_category_badge(report.get("final_category"))}</div>
                </div>
                <div>
                    <div class="sf-legacy-label">Confianza</div>
                    <div class="sf-legacy-value">{_display_text(report.get("confidence_level"))}</div>
                </div>
                <div>
                    <div class="sf-legacy-label">Coste IA</div>
                    <div class="sf-legacy-value">${float(estimated_cost or 0):.4f}</div>
                </div>
                <div>
                    <div class="sf-legacy-label">Analysis ID</div>
                    <div class="sf-legacy-value">{_display_text(report.get("_analysis_id"))}</div>
                </div>
            </div>
            <div class="sf-legacy-small">
                Modelo: {_display_text(model_name)} ·
                Tokens: {_display_text(report.get("_input_tokens"))} entrada /
                {_display_text(report.get("_output_tokens"))} salida
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    with st.expander("Ver scores estructurados", expanded=False):
        score_cols = st.columns(4)
        score_cols[0].metric("Modelo negocio", _format_score_or_dash(report.get("business_quality_score")))
        score_cols[1].metric("Salud financiera", _format_score_or_dash(report.get("financial_health_score")))
        score_cols[2].metric("Crecimiento", _format_score_or_dash(report.get("growth_score")))
        score_cols[3].metric("Valoración", _format_score_or_dash(report.get("valuation_score")))

        score_cols = st.columns(3)
        score_cols[0].metric("Riesgo", _format_score_or_dash(report.get("risk_score")))
        score_cols[1].metric("Moat", _format_score_or_dash(report.get("moat_score")))
        score_cols[2].metric("Confianza", _format_score_or_dash(report.get("confidence_score")))

    with st.expander("Fortalezas, riesgos y datos faltantes", expanded=False):
        col_a, col_b = st.columns(2)

        with col_a:
            _render_list_items("Fortalezas principales", report.get("top_strengths"))
            st.divider()
            _render_list_items("Catalizadores", report.get("catalysts"))

        with col_b:
            _render_list_items("Riesgos principales", report.get("top_risks"))
            st.divider()
            _render_list_items("Datos faltantes", report.get("missing_data"))

    with st.expander("Escenarios y señales a vigilar", expanded=False):
        st.write("**Escenario alcista**")
        st.write(_display_text(report.get("bull_case")))

        st.write("**Escenario base**")
        st.write(_display_text(report.get("base_case")))

        st.write("**Escenario bajista**")
        st.write(_display_text(report.get("bear_case")))

        st.divider()
        _render_list_items("Señales a vigilar", report.get("watchlist_metrics"))

    with st.expander("Ver informe Markdown completo", expanded=False):
        markdown_report = report.get("markdown_report")

        if markdown_report:
            _render_compact_legacy_markdown(markdown_report)
        else:
            st.info("El análisis existe, pero no contiene markdown_report.")


def _project_root() -> Path:
    """
    Return project root based on app.py location.
    """

    return Path(__file__).resolve().parent


def _outputs_dir() -> Path:
    """
    Return Phase 2 analyses output directory.
    """

    return _project_root() / "outputs" / "analyses"


def _find_latest_analysis_output_files(ticker: str) -> dict[str, Path]:
    """
    Find latest generated Phase 2 output files for a ticker.

    Expected naming pattern:
        TICKER_YYYYMMDD_HHMMSS.md
        TICKER_YYYYMMDD_HHMMSS.json
        TICKER_YYYYMMDD_HHMMSS_scorecard.png
        TICKER_YYYYMMDD_HHMMSS_scenarios.png
        TICKER_YYYYMMDD_HHMMSS_executive_card.html
    """

    analyses_dir = _outputs_dir()

    if not analyses_dir.exists():
        return {}

    ticker_token = str(ticker).upper().strip()
    json_files = sorted(
        analyses_dir.glob(f"{ticker_token}_*.json"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )

    if not json_files:
        return {}

    json_path = json_files[0]
    stem = json_path.stem

    candidates = {
        "json": json_path,
        "markdown": analyses_dir / f"{stem}.md",
        "scorecard_png": analyses_dir / f"{stem}_scorecard.png",
        "scenarios_png": analyses_dir / f"{stem}_scenarios.png",
        "executive_card_html": analyses_dir / f"{stem}_executive_card.html",
    }

    return {key: path for key, path in candidates.items() if path.exists()}


def _read_text_file(path: Path) -> str:
    """
    Read text file safely.
    """

    return path.read_text(encoding="utf-8", errors="replace")


def _download_file_button(label: str, path: Path, mime: str) -> None:
    """
    Render a Streamlit download button for a file path.
    """

    st.download_button(
        label=label,
        data=path.read_bytes(),
        file_name=path.name,
        mime=mime,
        use_container_width=True,
    )


def _html_open_link(path: Path) -> str:
    """
    Build a data URL for opening an HTML file in a new browser tab.
    """

    encoded = base64.b64encode(path.read_bytes()).decode("utf-8")
    return f"data:text/html;base64,{encoded}"



def _load_latest_phase2_json_summary(files: dict[str, Path]) -> dict[str, Any]:
    """
    Load a compact summary from the latest Phase 2 JSON output.
    """

    json_path = files.get("json")

    if json_path is None or not json_path.exists():
        return {}

    try:
        data = json.loads(_read_text_file(json_path))
    except json.JSONDecodeError:
        return {}

    if not isinstance(data, dict):
        return {}

    final_result = data.get("final_result", {})
    scores = data.get("scores", {})

    if not isinstance(final_result, dict):
        final_result = {}

    if not isinstance(scores, dict):
        scores = {}

    return {
        "final_category": final_result.get("final_category"),
        "confidence_level": final_result.get("confidence_level"),
        "confidence_score": scores.get("confidence_score"),
        "risk_score": scores.get("risk_score"),
        "business_quality_score": scores.get("business_quality_score"),
        "output_json": data,
    }


def _format_phase2_score(value: Any) -> str:
    """
    Format Phase 2 scores in 0-10 scale.
    """

    if _is_missing(value):
        return "—"

    try:
        return f"{float(value):.1f}/10"
    except (TypeError, ValueError):
        return str(value)




def _phase2_score_to_float(value: Any) -> float | None:
    """
    Convert Phase 2 score to float or None.
    """

    if _is_missing(value):
        return None

    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _phase2_score_color(value: Any, is_risk: bool = False) -> str:
    """
    Return semantic color for Phase 2 0-10 scores.
    """

    score = _phase2_score_to_float(value)

    if score is None:
        return "#94a3b8"

    if is_risk:
        if score <= 3:
            return "#16a34a"
        if score <= 6:
            return "#f97316"
        return "#dc2626"

    if score >= 8:
        return "#16a34a"
    if score >= 6.5:
        return "#2563eb"
    if score >= 5:
        return "#f97316"
    return "#dc2626"


def _phase2_score_label(value: Any, is_risk: bool = False) -> str:
    """
    Convert Phase 2 score to readable Spanish label.
    """

    score = _phase2_score_to_float(value)

    if score is None:
        return "Sin datos"

    if is_risk:
        if score <= 3:
            return "Riesgo bajo"
        if score <= 6:
            return "Riesgo medio"
        return "Riesgo alto"

    if score >= 8:
        return "Muy fuerte"
    if score >= 6.5:
        return "Bueno"
    if score >= 5:
        return "Aceptable"
    if score >= 3:
        return "Débil"
    return "Muy débil"


def _phase2_score_width(value: Any) -> float:
    """
    Return score width in percent for 0-10 scale.
    """

    score = _phase2_score_to_float(value)

    if score is None:
        return 0

    return max(0, min(100, score * 10))


def _phase2_category_style(category: Any) -> tuple[str, str, str, str]:
    """
    Return icon/background/border/text color for final category badge.
    """

    text = _display_text(category)

    if "Alta calidad" in text:
        return "🟢", "#ecfdf5", "#bbf7d0", "#166534"
    if "Interesante pero cara" in text:
        return "🔵", "#eff6ff", "#bfdbfe", "#1d4ed8"
    if "margen de seguridad" in text:
        return "🟡", "#fffbeb", "#fde68a", "#92400e"
    if "Riesgo elevado" in text:
        return "🟠", "#fff7ed", "#fed7aa", "#9a3412"
    if "Descartar" in text:
        return "🔴", "#fef2f2", "#fecaca", "#991b1b"
    if "Datos insuficientes" in text:
        return "⚫", "#f8fafc", "#cbd5e1", "#334155"

    return "ℹ️", "#f8fafc", "#cbd5e1", "#334155"


def _inject_phase2_streamlit_styles() -> None:
    """
    Inject CSS for polished Phase 2 cards.
    """

    st.markdown(
        """
        <style>
        .sf2-card {
            border: 1px solid #e5e7eb;
            border-radius: 22px;
            padding: 22px 24px;
            background: #ffffff;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
            margin: 12px 0 18px 0;
        }
        .sf2-card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
        }
        .sf2-title {
            font-size: 1.06rem;
            font-weight: 800;
            color: #0f172a;
            margin-bottom: 4px;
        }
        .sf2-subtitle {
            font-size: 0.88rem;
            color: #64748b;
            margin-bottom: 14px;
        }
        .sf2-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border: 1px solid;
            border-radius: 999px;
            padding: 10px 14px;
            font-weight: 800;
            max-width: 100%;
            white-space: normal;
        }
        .sf2-main-score {
            font-size: 3.2rem;
            font-weight: 850;
            letter-spacing: -0.05em;
            line-height: 1;
        }
        .sf2-main-score span {
            font-size: 1rem;
            color: #475569;
            letter-spacing: 0;
            font-weight: 650;
        }
        .sf2-score-label {
            font-weight: 800;
            margin-top: 6px;
        }
        .sf2-track {
            height: 10px;
            border-radius: 999px;
            background: #e5e7eb;
            overflow: hidden;
            margin-top: 10px;
            max-width: 320px;
        }
        .sf2-fill {
            height: 100%;
            border-radius: 999px;
        }
        .sf2-mini-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(130px, 1fr));
            gap: 12px;
            margin-top: 18px;
        }
        .sf2-mini-card {
            border: 1px solid #eef2f7;
            border-radius: 16px;
            padding: 14px 15px;
            background: #f8fafc;
        }
        .sf2-mini-label {
            color: #64748b;
            font-size: 0.78rem;
            margin-bottom: 4px;
        }
        .sf2-mini-value {
            color: #0f172a;
            font-size: 1.15rem;
            font-weight: 850;
            line-height: 1.15;
            white-space: normal;
            overflow-wrap: anywhere;
        }
        .sf2-module-row {
            display: grid;
            grid-template-columns: 1.2fr 2fr auto;
            gap: 12px;
            align-items: center;
            margin-top: 10px;
        }
        .sf2-module-name {
            font-weight: 750;
            color: #0f172a;
        }
        .sf2-module-score {
            font-weight: 850;
            min-width: 54px;
            text-align: right;
        }
        .sf2-note {
            margin-top: 14px;
            color: #64748b;
            font-size: 0.83rem;
        }
        @media (max-width: 900px) {
            .sf2-mini-grid {
                grid-template-columns: repeat(2, minmax(130px, 1fr));
            }
            .sf2-module-row {
                grid-template-columns: 1fr;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _render_phase2_summary_card(summary: dict[str, Any], output_id: str) -> None:
    """
    Render polished Phase 2 summary card.

    Important:
    Streamlit Markdown can display indented HTML as a code block.
    For that reason, the HTML is dedented before rendering.
    """

    _inject_phase2_streamlit_styles()

    category = summary.get("final_category")
    confidence_level = _display_text(summary.get("confidence_level"))
    confidence_score = summary.get("confidence_score")
    risk_score = summary.get("risk_score")
    business_quality_score = summary.get("business_quality_score")

    icon, bg, border, text_color = _phase2_category_style(category)
    confidence_color = _phase2_score_color(confidence_score)
    confidence_width = _phase2_score_width(confidence_score)
    confidence_label = _phase2_score_label(confidence_score)

    if _phase2_score_to_float(confidence_score) is None:
        confidence_text = "—"
        confidence_suffix = ""
    else:
        confidence_text = f"{float(confidence_score):.1f}"
        confidence_suffix = "<span>/10</span>"

    html_block = f"""
<div class="sf2-card">
  <div class="sf2-card-header">
    <div>
      <div class="sf2-title">📊 Resumen ejecutivo Fase 2</div>
      <div class="sf2-subtitle">Lectura rápida desde el JSON validado · escala 0-10</div>
      <div class="sf2-main-score" style="color:{confidence_color};">
        {confidence_text} {confidence_suffix}
      </div>
      <div class="sf2-score-label" style="color:{confidence_color};">{confidence_label}</div>
      <div class="sf2-track">
        <div class="sf2-fill" style="width:{confidence_width}%; background:{confidence_color};"></div>
      </div>
    </div>
    <div>
      <div class="sf2-badge" style="background:{bg}; border-color:{border}; color:{text_color};">
        <span>{icon}</span>
        <span>{_display_text(category)}</span>
      </div>
    </div>
  </div>

  <div class="sf2-mini-grid">
    <div class="sf2-mini-card">
      <div class="sf2-mini-label">Confianza</div>
      <div class="sf2-mini-value">{confidence_level}</div>
    </div>
    <div class="sf2-mini-card">
      <div class="sf2-mini-label">Calidad negocio</div>
      <div class="sf2-mini-value">{_format_phase2_score(business_quality_score)}</div>
    </div>
    <div class="sf2-mini-card">
      <div class="sf2-mini-label">Riesgo</div>
      <div class="sf2-mini-value">{_format_phase2_score(risk_score)}</div>
    </div>
    <div class="sf2-mini-card">
      <div class="sf2-mini-label">Output</div>
      <div class="sf2-mini-value">{output_id}</div>
    </div>
  </div>

  <div class="sf2-note">
    En riesgo, más bajo es mejor. Esta tarjeta no representa recomendación de inversión.
  </div>
</div>
"""

    st.markdown(textwrap.dedent(html_block).strip(), unsafe_allow_html=True)


def _render_phase2_module_strip(summary: dict[str, Any]) -> None:
    """
    Render a compact row-list of key Phase 2 module scores.
    """

    data = summary.get("output_json", {})
    scores = data.get("scores", {}) if isinstance(data, dict) else {}

    if not isinstance(scores, dict):
        return

    modules = [
        ("Calidad negocio", scores.get("business_quality_score"), False),
        ("Moat", scores.get("moat_score"), False),
        ("Evidencia", scores.get("evidence_quality_score"), False),
        ("Actualidad datos", scores.get("data_freshness_score"), False),
        ("Riesgo", scores.get("risk_score"), True),
    ]

    rows_html = ""

    for name, value, is_risk in modules:
        color = _phase2_score_color(value, is_risk=is_risk)
        width = _phase2_score_width(value)
        label = _phase2_score_label(value, is_risk=is_risk)
        score_text = _format_phase2_score(value)

        rows_html += f"""
<div class="sf2-module-row">
  <div>
    <div class="sf2-module-name">{name}</div>
    <div class="sf2-note" style="margin-top:2px;">{label}</div>
  </div>
  <div class="sf2-track">
    <div class="sf2-fill" style="width:{width}%; background:{color};"></div>
  </div>
  <div class="sf2-module-score" style="color:{color};">{score_text}</div>
</div>
"""

    html_block = f"""
<div class="sf2-card">
  <div class="sf2-title">🧩 Módulos clave</div>
  <div class="sf2-subtitle">Resumen visual compacto generado desde el JSON estructurado.</div>
  {rows_html}
</div>
"""

    st.markdown(textwrap.dedent(html_block).strip(), unsafe_allow_html=True)


def _render_generated_outputs_section(ticker: str) -> None:
    """
    Render generated Phase 2 analysis output files in Streamlit.
    """

    st.markdown("#### 📁 Fase 2 — Outputs estructurados generados")

    files = _find_latest_analysis_output_files(ticker)

    if not files:
        st.info(
            "No hay outputs generados para esta empresa todavía. "
            "Para generarlos ejecuta: `python -m src.company_research_report_outputs`."
        )
        return

    json_path = files.get("json")
    output_id = json_path.stem if json_path else "output"
    summary = _load_latest_phase2_json_summary(files)

    st.caption(f"Último output detectado para {ticker}: `{output_id}`")
    st.info(
        "Este es el bloque principal de Fase 2: usa JSON estructurado validado en escala 0-10 "
        "y genera archivos reutilizables para histórico, comparación y portfolio."
    )

    _render_phase2_summary_card(summary, output_id)
    _render_phase2_module_strip(summary)

    col1, col2, col3 = st.columns(3)

    with col1:
        if "markdown" in files:
            _download_file_button(
                "Descargar Markdown",
                files["markdown"],
                "text/markdown",
            )

    with col2:
        if "json" in files:
            _download_file_button(
                "Descargar JSON",
                files["json"],
                "application/json",
            )

    with col3:
        if "executive_card_html" in files:
            _download_file_button(
                "Descargar HTML",
                files["executive_card_html"],
                "text/html",
            )

    if "executive_card_html" in files:
        html_url = _html_open_link(files["executive_card_html"])
        st.markdown(
            f'<a href="{html_url}" target="_blank">Abrir ficha ejecutiva HTML en nueva pestaña</a>',
            unsafe_allow_html=True,
        )
        st.caption(
            "Recomendado: abre la ficha HTML en nueva pestaña para verla completa. "
            "La previsualización dentro de Streamlit es solo una vista rápida."
        )

    with st.expander("📊 Ver scorecard PNG", expanded=True):
        if "scorecard_png" in files:
            st.image(str(files["scorecard_png"]), use_container_width=True)
            _download_file_button(
                "Descargar scorecard PNG",
                files["scorecard_png"],
                "image/png",
            )
        else:
            st.info("No se encontró el scorecard PNG.")

    with st.expander("📈 Ver escenarios PNG", expanded=False):
        if "scenarios_png" in files:
            st.image(str(files["scenarios_png"]), use_container_width=True)
            _download_file_button(
                "Descargar escenarios PNG",
                files["scenarios_png"],
                "image/png",
            )
        else:
            st.info("No se encontró el gráfico de escenarios PNG.")

    with st.expander("📄 Ver informe Markdown generado", expanded=False):
        if "markdown" in files:
            st.markdown(_read_text_file(files["markdown"]))
        else:
            st.info("No se encontró el archivo Markdown.")

    with st.expander("🧬 Ver JSON estructurado generado", expanded=False):
        if "json" in files:
            try:
                json_data = json.loads(_read_text_file(files["json"]))
                st.json(json_data)
            except json.JSONDecodeError:
                st.code(_read_text_file(files["json"]), language="json")
        else:
            st.info("No se encontró el archivo JSON.")

    with st.expander("🪪 Previsualización rápida HTML", expanded=False):
        st.caption(
            "Esta vista puede aparecer recortada dentro de Streamlit. "
            "Para revisar la ficha correctamente, usa el enlace de nueva pestaña."
        )

        if "executive_card_html" in files:
            st.components.v1.html(
                _read_text_file(files["executive_card_html"]),
                height=760,
                scrolling=True,
            )
        else:
            st.info("No se encontró la ficha ejecutiva HTML.")


def _render_company_detail(final_df: pd.DataFrame, mode: str) -> None:
    """
    Render individual company detail card with score breakdown and quick feedback.
    """

    st.subheader("📄 Ficha individual de empresa")

    if final_df.empty:
        st.info("No hay empresas disponibles para mostrar en la ficha.")
        return

    latest_run_id = get_latest_run_id(mode=mode)

    tickers = final_df["ticker"].dropna().astype(str).tolist()

    selected_ticker = st.selectbox(
        "Seleccionar empresa",
        options=tickers,
        format_func=lambda ticker: (
            f"{ticker} — "
            f"{final_df.loc[final_df['ticker'] == ticker, 'company_name'].iloc[0]}"
            if "company_name" in final_df.columns
            else ticker
        ),
    )

    row = final_df[final_df["ticker"] == selected_ticker].iloc[0]
    rank = int(final_df.reset_index(drop=True).index[final_df["ticker"] == selected_ticker][0]) + 1

    title = f"#{rank} · {_display_text(row.get('ticker'))} — {_display_text(row.get('company_name'))}"
    st.markdown(f"### {title}")

    col1, col2, col3, col4 = st.columns(4)

    col1.metric("Score", _format_number(row.get("score_priority"), 2))
    col2.metric("Categoría", _category_label(row.get("category_final")))
    col3.metric("Riesgo", _format_number(row.get("score_risk"), 2))
    col4.metric("Confianza", _format_number(row.get("score_confidence"), 2))

    st.caption(_score_help_text())

    with st.expander("Ver desglose del score"):
        score_cols = st.columns(5)
        score_cols[0].metric("Volumen", _format_number(row.get("score_volume"), 2))
        score_cols[1].metric("Momentum", _format_number(row.get("score_momentum"), 2))
        score_cols[2].metric("Liquidez", _format_number(row.get("score_liquidity"), 2))
        score_cols[3].metric("Contexto", _format_number(row.get("score_context"), 2))
        score_cols[4].metric("Ajustado", _format_number(row.get("score_adjusted"), 2))

    col1, col2, col3, col4 = st.columns(4)

    col1.metric("Precio", _format_number(row.get("price_at_signal"), 2))
    col2.metric("Market Cap", _format_compact_usd(row.get("market_cap")))
    col3.metric("Vol. relativo", _format_number(row.get("relative_volume"), 2))
    col4.metric("Calidad datos", _display_text(row.get("data_quality_label")))

    col1, col2, col3 = st.columns(3)

    col1.metric("1D", _format_percent_ratio(row.get("change_1d")))
    col2.metric("5D", _format_percent_ratio(row.get("change_5d")))
    col3.metric("20D", _format_percent_ratio(row.get("change_20d")))

    st.markdown("#### Contexto")
    context_col1, context_col2, context_col3 = st.columns(3)

    with context_col1:
        st.write("**Sector**")
        st.write(_display_text(row.get("sector")))

    with context_col2:
        st.write("**Industria**")
        st.write(_display_text(row.get("industry")))

    with context_col3:
        st.write("**Exchange / Divisa**")
        st.write(f"{_display_text(row.get('exchange'))} / {_display_text(row.get('currency'))}")

    st.markdown("#### Razón cuantitativa")
    reason_quant = _quant_reason_label(row.get("reason_to_pass_quant"))
    st.info(reason_quant)

    st.markdown("#### 🧠 Estado IA legacy resumido")

    _sf_local_values = locals()

    def _sf_pick_value(*names):
        for name in names:
            if name in _sf_local_values:
                value = _sf_local_values.get(name)
                if not _is_missing(value):
                    return value

        row_candidates = ["selected_row", "company_row", "row", "selected_company", "company_data", "company"]

        for row_name in row_candidates:
            candidate = _sf_local_values.get(row_name)

            if candidate is None:
                continue

            for name in names:
                try:
                    if hasattr(candidate, 'get'):
                        value = candidate.get(name)
                    else:
                        value = candidate[name]
                except Exception:
                    continue

                if not _is_missing(value):
                    return value

        return None

    _legacy_openai_model = _sf_pick_value("openai_model", "model", "_model", "Modelo IA", "Modelo")
    _legacy_openai_state = _sf_pick_value("openai_state", "estado_ia", "ai_state", "Estado IA", "Estado")
    _legacy_summary_thesis = _sf_pick_value("summary_thesis", "tesis", "Tesis", "thesis")
    _legacy_why_work = _sf_pick_value("why_it_could_work", "why_work", "por_que_podria_funcionar", "Por qué podría funcionar")
    _legacy_why_fail = _sf_pick_value("why_it_could_fail", "why_fail", "por_que_podria_fallar", "Por qué podría fallar")

    legacy_cols = st.columns(2)

    with legacy_cols[0]:
        if not _is_missing(_legacy_openai_model):
            st.write(f"**Modelo:** {_legacy_openai_model}")
        else:
            st.write("**Modelo:** —")

    with legacy_cols[1]:
        if not _is_missing(_legacy_openai_state):
            st.write(f"**Estado:** {_legacy_openai_state}")
        else:
            st.write("**Estado:** —")

    if st.toggle("Mostrar explicación IA legacy", value=False, help="Muestra la tesis legacy anterior. La vista principal actual es Fase 2."):
        st.caption(
            "Este resumen procede del análisis IA anterior. "
            "La visualización principal actual está en Fase 2 y usa JSON estructurado 0-10."
        )

        if not _is_missing(_legacy_summary_thesis):
            st.write("**Tesis:**")
            st.write(_legacy_summary_thesis)
        else:
            st.write("**Tesis:** —")

        if not _is_missing(_legacy_why_work):
            st.write("**Por qué podría funcionar:**")
            st.write(_legacy_why_work)

        if not _is_missing(_legacy_why_fail):
            st.write("**Por qué podría fallar:**")
            st.write(_legacy_why_fail)

    _render_generated_outputs_section(selected_ticker)

    with st.expander("🧠 Análisis IA legacy — Company Research Report v0.2", expanded=False):
        st.caption(
            "Este bloque mantiene el análisis antiguo guardado en SQLite. "
            "Puede usar scores en escala 0-100. La visualización principal actual es Fase 2, basada en JSON 0-10."
        )
        company_report_v2 = _get_latest_company_report_v2(
            ticker=selected_ticker,
            run_id=latest_run_id,
            mode=mode,
        )
        _render_company_research_report_v2(company_report_v2)

    st.markdown("#### Feedback manual")
    feedback_label = _feedback_label(row.get("feedback_label"))
    feedback_notes = _display_text(row.get("feedback_notes"))
    reviewed_by = _display_text(row.get("reviewed_by"))

    st.write(f"**Feedback actual:** {feedback_label}")
    st.write(f"**Notas:** {feedback_notes}")
    st.write(f"**Revisado por:** {reviewed_by}")

    with st.expander("Guardar feedback rápido para esta empresa"):
        labels = get_valid_feedback_labels()
        label_display_map = {FEEDBACK_LABELS.get(label, label): label for label in labels}
        label_display_options = list(label_display_map.keys())

        default_label = (
            "Investigar más"
            if "Investigar más" in label_display_options
            else label_display_options[0]
        )

        quick_col1, quick_col2 = st.columns(2)

        with quick_col1:
            selected_label_display = st.selectbox(
                "Etiqueta rápida",
                options=label_display_options,
                index=label_display_options.index(default_label),
                key=f"quick_feedback_label_{selected_ticker}",
            )
            quick_feedback_label = label_display_map[selected_label_display]

        with quick_col2:
            quick_reviewed_by = st.text_input(
                "Revisado por",
                value="Iker",
                key=f"quick_reviewed_by_{selected_ticker}",
            )

        quick_notes = st.text_area(
            "Notas rápidas",
            placeholder="Motivo del feedback...",
            key=f"quick_notes_{selected_ticker}",
        )

        if st.button("Guardar feedback rápido", key=f"quick_feedback_button_{selected_ticker}"):
            feedback_id = _safe_run_action(
                "guardar feedback rápido",
                add_manual_feedback_by_ticker,
                ticker=selected_ticker,
                feedback_label=quick_feedback_label,
                notes=quick_notes,
                reviewed_by=quick_reviewed_by,
                run_id=latest_run_id,
                mode=mode,
            )

            if feedback_id:
                st.success(f"Feedback guardado. ID: {feedback_id}")
                st.rerun()

    with st.expander("Ver histórico de feedback de esta empresa"):
        if latest_run_id is None:
            st.info("No hay run activo.")
        else:
            feedback_history = load_manual_feedback(run_id=latest_run_id, mode=mode)

            if feedback_history.empty:
                st.info("No hay feedback guardado todavía.")
            else:
                ticker_history = feedback_history[
                    feedback_history["ticker"].astype(str) == selected_ticker
                ].copy()

                if ticker_history.empty:
                    st.info("No hay feedback para esta empresa.")
                else:
                    columns = [
                        "created_at",
                        "feedback_label",
                        "notes",
                        "reviewed_by",
                    ]
                    available_columns = [column for column in columns if column in ticker_history.columns]
                    history_display = ticker_history[available_columns].copy()

                    if "feedback_label" in history_display.columns:
                        history_display["feedback_label"] = history_display["feedback_label"].apply(_feedback_label)

                    history_display = history_display.rename(
                        columns={
                            "created_at": "Fecha",
                            "feedback_label": "Feedback",
                            "notes": "Notas",
                            "reviewed_by": "Revisado por",
                        }
                    )

                    st.dataframe(
                        history_display.fillna(""),
                        use_container_width=True,
                        hide_index=True,
                    )


def _render_visual_dashboard(final_df: pd.DataFrame) -> None:
    """
    Render basic visual dashboard from the filtered final view.
    """

    st.subheader("📈 Resumen visual")

    if final_df.empty:
        st.info("No hay datos para gráficos con los filtros actuales.")
        return

    chart_col1, chart_col2 = st.columns(2)

    with chart_col1:
        st.markdown("**Top empresas por score**")
        top_score_df = final_df[["ticker", "score_priority"]].copy()
        top_score_df = top_score_df.dropna(subset=["ticker", "score_priority"])
        top_score_df = top_score_df.sort_values("score_priority", ascending=False).head(10)
        top_score_df = top_score_df.set_index("ticker")
        st.bar_chart(top_score_df)

    with chart_col2:
        st.markdown("**Distribución por categoría**")
        if "category_final" in final_df.columns:
            category_counts = (
                final_df["category_final"]
                .dropna()
                .apply(_category_label)
                .value_counts()
                .rename_axis("Categoría")
                .reset_index(name="Empresas")
                .set_index("Categoría")
            )
            st.bar_chart(category_counts)
        else:
            st.info("No hay columna de categoría.")

    chart_col3, chart_col4 = st.columns(2)

    with chart_col3:
        st.markdown("**Distribución por sector**")
        if "sector" in final_df.columns:
            sector_counts = (
                final_df["sector"]
                .dropna()
                .value_counts()
                .rename_axis("Sector")
                .reset_index(name="Empresas")
                .set_index("Sector")
            )
            st.bar_chart(sector_counts)
        else:
            st.info("No hay columna de sector.")

    with chart_col4:
        st.markdown("**Cobertura OpenAI / Feedback**")

        openai_with = (
            int(final_df["openai_analysis_id"].notna().sum())
            if "openai_analysis_id" in final_df.columns
            else 0
        )
        feedback_with = (
            int(final_df["feedback_id"].notna().sum())
            if "feedback_id" in final_df.columns
            else 0
        )

        coverage_df = pd.DataFrame(
            {
                "Tipo": ["Con OpenAI", "Sin OpenAI", "Con feedback", "Sin feedback"],
                "Empresas": [
                    openai_with,
                    len(final_df) - openai_with,
                    feedback_with,
                    len(final_df) - feedback_with,
                ],
            }
        ).set_index("Tipo")

        st.bar_chart(coverage_df)


def _dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
    """
    Convert dataframe to CSV bytes for Streamlit download.
    """

    return df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig")


def _dataframe_to_excel_bytes(df: pd.DataFrame, sheet_name: str = "results") -> bytes:
    """
    Convert dataframe to Excel bytes for Streamlit download.
    """

    output = io.BytesIO()

    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name=sheet_name, index=False)

    return output.getvalue()


def _render_direct_downloads(display_df: pd.DataFrame, technical_df: pd.DataFrame) -> None:
    """
    Render direct download buttons for current filtered data.
    """

    st.subheader("⬇️ Descarga directa")

    if technical_df.empty:
        st.info("No hay datos para descargar.")
        return

    col1, col2, col3 = st.columns(3)

    with col1:
        st.download_button(
            label="Descargar tabla visible CSV",
            data=_dataframe_to_csv_bytes(display_df),
            file_name="equity_research_tabla_visible.csv",
            mime="text/csv",
            use_container_width=True,
        )

    with col2:
        st.download_button(
            label="Descargar vista técnica CSV",
            data=_dataframe_to_csv_bytes(technical_df),
            file_name="equity_research_vista_tecnica.csv",
            mime="text/csv",
            use_container_width=True,
        )

    with col3:
        excel_bytes = _dataframe_to_excel_bytes(technical_df, sheet_name="final_view")
        st.download_button(
            label="Descargar Excel",
            data=excel_bytes,
            file_name="equity_research_final_view.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )




def _render_phase3b_json_comparison() -> None:
    """
    Render visual comparison from generated structured JSON outputs.

    Phase 4D:
    - Uses only JSON files already generated in outputs/analyses.
    - Does not call OpenAI.
    - Adds visual cards and rankings before the technical table.
    """

    st.markdown("### 🧮 Comparativa visual — análisis JSON generados")
    st.caption(
        "Compara los análisis ya generados en `outputs/analyses/`. "
        "No llama a OpenAI y no gasta tokens."
    )

    analyses_dir = Path(__file__).resolve().parent / "outputs" / "analyses"
    latest_only = st.checkbox(
        "Mostrar solo el último análisis por ticker",
        value=True,
        help="Si lo desactivas, verás también históricos anteriores del mismo ticker.",
    )

    comparison_df = build_analysis_comparison_df(
        output_dir=analyses_dir,
        latest_only=latest_only,
    )

    if comparison_df.empty:
        st.info(
            "No hay JSON estructurados todavía. "
            "Genera primero outputs con `python -m src.company_research_report_outputs --top-n 3`."
        )
        return

    summary = summarize_analysis_history(comparison_df)
    display_df = build_display_comparison_df(comparison_df)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Empresas", summary.get("companies", 0))
    avg_confidence = summary.get("avg_confidence")
    col2.metric("Confianza media", "—" if avg_confidence is None else f"{avg_confidence:.1f}/10")
    avg_risk = summary.get("avg_risk")
    col3.metric(
        "Riesgo medio",
        "—" if avg_risk is None else f"{avg_risk:.1f}/10",
        help="En riesgo, más bajo es mejor.",
    )
    col4.metric("Datos insuficientes", summary.get("insufficient_data_count", 0))

    st.markdown("#### 🧭 Lectura rápida con avisos")
    _render_phase4d_company_cards(display_df)

    st.markdown("#### 🏁 Rankings rápidos")
    _render_phase4d_rankings(display_df)

    st.markdown("#### 📋 Tabla comparativa")
    st.dataframe(display_df, use_container_width=True, hide_index=True)

    st.download_button(
        label="Descargar comparativa CSV",
        data=export_comparison_csv_bytes(display_df),
        file_name="scout_finance_comparativa_json.csv",
        mime="text/csv",
        use_container_width=True,
    )

    with st.expander("Ver tabla técnica completa", expanded=False):
        st.dataframe(comparison_df, use_container_width=True, hide_index=True)

    with st.expander("Notas de lectura", expanded=False):
        st.markdown(
            """
            - La comparativa se basa en JSON ya validados.
            - `risk_score` usa escala inversa: 0 = riesgo bajo, 10 = riesgo alto.
            - Una categoría positiva con confianza media/baja debe interpretarse como análisis preliminar.
            - Esta vista no recomienda comprar, vender ni mantener.
            """
        )


def _sf_phase4d_pick_column(df: pd.DataFrame, candidates: list[str]) -> str | None:
    """
    Return first matching column.
    """

    if df is None or df.empty:
        return None

    for column in candidates:
        if column in df.columns:
            return column

    return None


def _sf_phase4d_value(row: pd.Series, candidates: list[str], default: str = "—") -> Any:
    """
    Safely read a value from a row using possible column names.
    """

    for column in candidates:
        if column in row.index:
            value = row.get(column)
            if not _is_missing(value):
                return value

    return default


def _sf_phase4d_number(value: Any) -> float | None:
    """
    Convert value to float safely.
    """

    try:
        if _is_missing(value):
            return None
        return float(value)
    except Exception:
        return None


def _sf_phase4d_badge_class(category: Any) -> str:
    """
    CSS class for category badge.
    """

    text = "" if _is_missing(category) else str(category).lower()

    if "alta calidad" in text or "seguir de cerca" in text:
        return "sf4d-badge-green"

    if "cara" in text:
        return "sf4d-badge-blue"

    if "margen" in text:
        return "sf4d-badge-yellow"

    if "riesgo" in text:
        return "sf4d-badge-orange"

    if "descartar" in text:
        return "sf4d-badge-red"

    if "datos insuficientes" in text:
        return "sf4d-badge-gray"

    return "sf4d-badge-neutral"


def _sf_phase4d_score_class(score: float | None, *, inverse: bool = False) -> str:
    """
    Color class for scores.

    inverse=True is used for risk: lower is better.
    """

    if score is None:
        return "sf4d-score-muted"

    if inverse:
        if score <= 3.5:
            return "sf4d-score-good"
        if score <= 6.5:
            return "sf4d-score-medium"
        return "sf4d-score-bad"

    if score >= 7:
        return "sf4d-score-good"
    if score >= 4.5:
        return "sf4d-score-medium"
    return "sf4d-score-bad"



def _sf_phase4d_category_reading(category: Any, confidence_score: float | None) -> str:
    """
    Short human-readable interpretation for a company card.

    It is derived from the category and confidence score.
    It does not introduce new financial advice.
    """

    text = "" if _is_missing(category) else str(category).lower()

    if "datos insuficientes" in text:
        return "Lectura: no comparable todavía por falta de datos."

    if confidence_score is not None and confidence_score < 4:
        return "Lectura: análisis débil; revisar fuentes antes de comparar."

    if "alta calidad" in text or "seguir de cerca" in text:
        return "Lectura: candidata principal para seguimiento."

    if "cara" in text:
        return "Lectura: interesante, pero la valoración exige prudencia."

    if "margen" in text:
        return "Lectura: solo atractiva si aparece margen de seguridad."

    if "riesgo" in text:
        return "Lectura: vigilar riesgos antes de profundizar."

    if "descartar" in text:
        return "Lectura: baja prioridad por ahora."

    return "Lectura: revisar junto con tabla técnica y limitaciones."


def _sf_phase4d_needs_warning(
    category: Any,
    confidence_score: float | None,
    evidence_score: float | None,
    limitations: Any,
) -> bool:
    """
    Return True when the card should show a prudence warning.
    """

    text = "" if _is_missing(category) else str(category).lower()

    if "datos insuficientes" in text:
        return True

    if confidence_score is not None and confidence_score < 4:
        return True

    if evidence_score is not None and evidence_score < 4:
        return True

    try:
        if not _is_missing(limitations) and int(float(limitations)) >= 5:
            return True
    except Exception:
        pass

    return False


def _sf_phase4d_warning_text(
    category: Any,
    confidence_score: float | None,
    evidence_score: float | None,
    limitations: Any,
) -> str:
    """
    Short warning shown inside the visual card.
    """

    text = "" if _is_missing(category) else str(category).lower()

    if "datos insuficientes" in text:
        return "⚠️ Datos insuficientes: no comparar como tesis sólida."

    if confidence_score is not None and confidence_score < 4:
        return "⚠️ Confianza baja: lectura preliminar."

    if evidence_score is not None and evidence_score < 4:
        return "⚠️ Evidencia débil: verificar fuentes."

    try:
        if not _is_missing(limitations) and int(float(limitations)) >= 5:
            return "⚠️ Muchas limitaciones de datos."
    except Exception:
        pass

    return "⚠️ Revisar limitaciones antes de decidir."



def _sf_phase4d_inject_styles() -> None:
    """
    Inject minimal CSS for visual comparison cards.
    """

    st.markdown(
        """
        <style>
        .sf4d-card {
            border: 1px solid #E5E7EB;
            border-radius: 18px;
            padding: 18px 18px 14px 18px;
            background: #FFFFFF;
            box-shadow: 0 8px 22px rgba(15, 23, 42, 0.05);
            min-height: 250px;
            margin-bottom: 12px;
        }
        .sf4d-card-title {
            font-size: 1.05rem;
            font-weight: 750;
            color: #111827;
            margin-bottom: 2px;
        }
        .sf4d-card-subtitle {
            color: #64748B;
            font-size: 0.84rem;
            margin-bottom: 12px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .sf4d-badge {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            margin-bottom: 12px;
            max-width: 100%;
        }
        .sf4d-badge-green { background: #DCFCE7; color: #166534; border: 1px solid #86EFAC; }
        .sf4d-badge-blue { background: #DBEAFE; color: #1D4ED8; border: 1px solid #93C5FD; }
        .sf4d-badge-yellow { background: #FEF3C7; color: #92400E; border: 1px solid #FCD34D; }
        .sf4d-badge-orange { background: #FFEDD5; color: #9A3412; border: 1px solid #FDBA74; }
        .sf4d-badge-red { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        .sf4d-badge-gray { background: #F1F5F9; color: #334155; border: 1px solid #CBD5E1; }
        .sf4d-badge-neutral { background: #F8FAFC; color: #334155; border: 1px solid #E2E8F0; }
        .sf4d-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px 12px;
            margin-top: 6px;
        }
        .sf4d-metric-label {
            color: #64748B;
            font-size: 0.74rem;
            margin-bottom: 2px;
        }
        .sf4d-metric-value {
            font-weight: 750;
            font-size: 1rem;
            color: #111827;
        }
        .sf4d-score-good { color: #16A34A; }
        .sf4d-score-medium { color: #F97316; }
        .sf4d-score-bad { color: #DC2626; }
        .sf4d-score-muted { color: #94A3B8; }
        .sf4d-note {
            color: #64748B;
            font-size: 0.78rem;
            margin-top: 12px;
        }
        .sf4d-reading {
            margin-top: 12px;
            padding: 9px 10px;
            border-radius: 12px;
            background: #F8FAFC;
            border: 1px solid #E2E8F0;
            color: #334155;
            font-size: 0.80rem;
            font-weight: 600;
        }
        .sf4d-warning {
            margin-top: 8px;
            padding: 9px 10px;
            border-radius: 12px;
            background: #FEF2F2;
            border: 1px solid #FCA5A5;
            color: #991B1B;
            font-size: 0.80rem;
            font-weight: 700;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _render_phase4d_company_cards(display_df: pd.DataFrame) -> None:
    """
    Render one visual card per company with short reading and warnings.
    """

    if display_df is None or display_df.empty:
        st.info("No hay datos para crear tarjetas comparativas.")
        return

    _sf_phase4d_inject_styles()

    rows = list(display_df.iterrows())
    columns_per_row = 3

    for start_index in range(0, len(rows), columns_per_row):
        cols = st.columns(columns_per_row)
        for col, (_, row) in zip(cols, rows[start_index:start_index + columns_per_row]):
            ticker = _sf_phase4d_value(row, ["Ticker", "ticker"], "—")
            company = _sf_phase4d_value(row, ["Empresa", "company_name", "Company"], "")
            category = _sf_phase4d_value(row, ["Categoría", "final_category"], "—")
            confidence_level = _sf_phase4d_value(row, ["Confianza", "confidence_level"], "—")

            confidence_score = _sf_phase4d_number(
                _sf_phase4d_value(row, ["Score confianza", "confidence_score"], None)
            )
            business_quality = _sf_phase4d_number(
                _sf_phase4d_value(row, ["Calidad negocio", "business_quality_score"], None)
            )
            risk = _sf_phase4d_number(
                _sf_phase4d_value(row, ["Riesgo", "risk_score"], None)
            )
            moat = _sf_phase4d_number(
                _sf_phase4d_value(row, ["Moat", "moat_score"], None)
            )
            evidence = _sf_phase4d_number(
                _sf_phase4d_value(row, ["Evidencia", "evidence_quality_score"], None)
            )

            source_warnings = _sf_phase4d_value(row, ["Avisos fuentes", "source_warnings_count"], "—")
            limitations = _sf_phase4d_value(row, ["Limitaciones", "data_limitations_count"], "—")

            category_class = _sf_phase4d_badge_class(category)
            reading_text = _sf_phase4d_category_reading(category, confidence_score)
            warning_needed = _sf_phase4d_needs_warning(category, confidence_score, evidence, limitations)
            warning_text = _sf_phase4d_warning_text(category, confidence_score, evidence, limitations)
            warning_html = f'<div class="sf4d-warning">{warning_text}</div>' if warning_needed else ""

            def fmt_score(value: float | None) -> str:
                return "—" if value is None else f"{value:.1f}/10"

            # Build the HTML card without blank indented lines.
            # Streamlit can render an indented HTML line as raw code when
            # warning_html is empty, so we join clean fragments instead.
            card_html_parts = [
                '<div class="sf4d-card">',
                f'<div class="sf4d-card-title">{ticker}</div>',
                f'<div class="sf4d-card-subtitle">{company}</div>',
                f'<div class="sf4d-badge {category_class}">{category}</div>',
                '<div class="sf4d-grid">',
                '<div>',
                '<div class="sf4d-metric-label">Confianza</div>',
                f'<div class="sf4d-metric-value {_sf_phase4d_score_class(confidence_score)}">{fmt_score(confidence_score)}</div>',
                '</div>',
                '<div>',
                '<div class="sf4d-metric-label">Riesgo</div>',
                f'<div class="sf4d-metric-value {_sf_phase4d_score_class(risk, inverse=True)}">{fmt_score(risk)}</div>',
                '</div>',
                '<div>',
                '<div class="sf4d-metric-label">Calidad negocio</div>',
                f'<div class="sf4d-metric-value {_sf_phase4d_score_class(business_quality)}">{fmt_score(business_quality)}</div>',
                '</div>',
                '<div>',
                '<div class="sf4d-metric-label">Moat</div>',
                f'<div class="sf4d-metric-value {_sf_phase4d_score_class(moat)}">{fmt_score(moat)}</div>',
                '</div>',
                '<div>',
                '<div class="sf4d-metric-label">Evidencia</div>',
                f'<div class="sf4d-metric-value {_sf_phase4d_score_class(evidence)}">{fmt_score(evidence)}</div>',
                '</div>',
                '<div>',
                '<div class="sf4d-metric-label">Confianza texto</div>',
                f'<div class="sf4d-metric-value">{confidence_level}</div>',
                '</div>',
                '</div>',
                f'<div class="sf4d-reading">{reading_text}</div>',
            ]

            if warning_html:
                card_html_parts.append(warning_html)

            card_html_parts.extend([
                f'<div class="sf4d-note">Avisos fuentes: {source_warnings} · Limitaciones: {limitations}</div>',
                '</div>',
            ])

            card_html = "".join(card_html_parts)
            col.markdown(card_html, unsafe_allow_html=True)


def _render_phase4d_rankings(display_df: pd.DataFrame) -> None:
    """
    Render quick rankings from display comparison dataframe.
    """

    if display_df is None or display_df.empty:
        return

    ticker_col = _sf_phase4d_pick_column(display_df, ["Ticker", "ticker"])
    company_col = _sf_phase4d_pick_column(display_df, ["Empresa", "company_name"])
    confidence_col = _sf_phase4d_pick_column(display_df, ["Score confianza", "confidence_score"])
    risk_col = _sf_phase4d_pick_column(display_df, ["Riesgo", "risk_score"])
    business_col = _sf_phase4d_pick_column(display_df, ["Calidad negocio", "business_quality_score"])
    category_col = _sf_phase4d_pick_column(display_df, ["Categoría", "final_category"])

    ranking_df = display_df.copy()

    for col_name in [confidence_col, risk_col, business_col]:
        if col_name:
            ranking_df[col_name] = pd.to_numeric(ranking_df[col_name], errors="coerce")

    col1, col2, col3 = st.columns(3)

    def simple_table(
        target_col,
        title: str,
        ascending: bool,
        help_text: str,
    ) -> None:
        if not target_col or ticker_col is None:
            st.info(f"No hay datos suficientes para {title.lower()}.")
            return

        cols = [ticker_col, target_col]
        if company_col:
            cols.insert(1, company_col)
        if category_col:
            cols.append(category_col)

        table_df = (
            ranking_df[cols]
            .dropna(subset=[target_col])
            .sort_values(target_col, ascending=ascending)
            .head(5)
            .copy()
        )

        if table_df.empty:
            st.info(f"No hay datos suficientes para {title.lower()}.")
            return

        st.caption(help_text)
        st.dataframe(table_df, use_container_width=True, hide_index=True)

    with col1:
        st.markdown("##### Mayor confianza")
        simple_table(
            confidence_col,
            "Mayor confianza",
            ascending=False,
            help_text="Prioriza análisis más utilizables.",
        )

    with col2:
        st.markdown("##### Menor riesgo")
        simple_table(
            risk_col,
            "Menor riesgo",
            ascending=True,
            help_text="En riesgo, más bajo es mejor.",
        )

    with col3:
        st.markdown("##### Mejor calidad negocio")
        simple_table(
            business_col,
            "Mejor calidad negocio",
            ascending=False,
            help_text="Ranking por calidad del negocio.",
        )



def _shorten_ai_state(value: Any) -> str:
    """
    Short label for the ranking table.
    Full label remains available in the complete table.
    """

    if _is_missing(value):
        return "—"

    text = str(value).strip()

    if not text:
        return "—"

    low = text.lower()

    if "interesante" in low or "investigar" in low:
        return "🟢 Investigar"

    if "desactiv" in low:
        return "IA desactivada"

    if "datos insuficientes" in low:
        return "⚫ Datos insuf."

    if "margen" in low:
        return "🟡 Margen seguridad"

    if "riesgo" in low:
        return "🟠 Riesgo"

    if "descartar" in low:
        return "🔴 Descartar"

    if len(text) > 22:
        return text[:19].rstrip() + "..."

    return text


def _normalize_ticker_key(value: Any) -> str:
    """
    Normalize ticker values for merging display and technical DataFrames.
    """

    if _is_missing(value):
        return ""

    return str(value).strip().upper()


def _shorten_ai_state(value: Any) -> str:
    """
    Short label for the ranking table.
    Full label remains available in the complete table.
    """

    if _is_missing(value):
        return "—"

    text = str(value).strip()

    if not text:
        return "—"

    low = text.lower()

    if "interesante" in low or "investigar" in low:
        return "🟢 Investigar"

    if "desactiv" in low:
        return "IA desactivada"

    if "datos insuficientes" in low:
        return "⚫ Datos insuf."

    if "margen" in low:
        return "🟡 Margen seguridad"

    if "riesgo" in low:
        return "🟠 Riesgo"

    if "descartar" in low:
        return "🔴 Descartar"

    if len(text) > 22:
        return text[:19].rstrip() + "..."

    return text


def _pick_column(df: pd.DataFrame, candidates: list[str]) -> str | None:
    """
    Return first column name found in DataFrame.
    """

    if df is None or df.empty:
        return None

    for column in candidates:
        if column in df.columns:
            return column

    return None


def _build_metric_lookup(
    filtered_df: pd.DataFrame,
    metric_candidates: list[str],
) -> dict[str, Any]:
    """
    Build ticker -> metric lookup from filtered_df.

    Used to recover values that are not present in display_df.
    """

    if filtered_df is None or filtered_df.empty:
        return {}

    ticker_col = _pick_column(filtered_df, ["Ticker", "ticker"])

    if ticker_col is None:
        return {}

    metric_col = _pick_column(filtered_df, metric_candidates)

    if metric_col is None:
        return {}

    lookup: dict[str, Any] = {}

    for _, row in filtered_df.iterrows():
        ticker_key = _normalize_ticker_key(row.get(ticker_col))

        if not ticker_key:
            continue

        value = row.get(metric_col)

        if not _is_missing(value):
            lookup[ticker_key] = value

    return lookup


def _build_clean_ranking_table(
    display_df: pd.DataFrame,
    filtered_df: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """
    Build a simplified ranking table for the main Ranking tab.

    Phase 4B.2:
    - Uses display_df for readable labels.
    - Recovers Riesgo/Confianza from filtered_df when missing.
    - Full technical table remains available in the technical expander/downloads.
    """

    if display_df is None or display_df.empty:
        return pd.DataFrame()

    preferred_columns = [
        "Rank",
        "Ticker",
        "Empresa",
        "Score",
        "Categoría",
        "Sector",
        "Riesgo",
        "Confianza",
        "Estado IA",
        "Feedback",
    ]

    fallback_map = {
        "rank": "Rank",
        "ticker": "Ticker",
        "company_name": "Empresa",
        "score_priority": "Score",
        "category_display": "Categoría",
        "sector": "Sector",
        "score_risk": "Riesgo",
        "risk_score": "Riesgo",
        "score_confidence": "Confianza",
        "confidence_score": "Confianza",
        "openai_status": "Estado IA",
        "openai_state": "Estado IA",
        "feedback_label": "Feedback",
    }

    clean_df = display_df.copy()

    for old_name, new_name in fallback_map.items():
        if old_name in clean_df.columns and new_name not in clean_df.columns:
            clean_df[new_name] = clean_df[old_name]

    # Recover Riesgo/Confianza from technical dataframe using ticker as key.
    ticker_col = _pick_column(clean_df, ["Ticker", "ticker"])

    if ticker_col is not None and filtered_df is not None and not filtered_df.empty:
        risk_lookup = _build_metric_lookup(
            filtered_df,
            [
                "Riesgo",
                "score_risk",
                "risk_score",
                "risk",
                "score_risk_adjusted",
                "risk_level_score",
            ],
        )
        confidence_lookup = _build_metric_lookup(
            filtered_df,
            [
                "Confianza",
                "score_confidence",
                "confidence_score",
                "confidence",
                "score_confidence_adjusted",
                "data_quality_score",
            ],
        )

        if "Riesgo" not in clean_df.columns and risk_lookup:
            clean_df["Riesgo"] = clean_df[ticker_col].map(
                lambda ticker: risk_lookup.get(_normalize_ticker_key(ticker))
            )

        if "Confianza" not in clean_df.columns and confidence_lookup:
            clean_df["Confianza"] = clean_df[ticker_col].map(
                lambda ticker: confidence_lookup.get(_normalize_ticker_key(ticker))
            )

    available_columns = [column for column in preferred_columns if column in clean_df.columns]

    if not available_columns:
        return display_df

    clean_df = clean_df[available_columns].copy()

    for numeric_column in ["Score", "Riesgo", "Confianza"]:
        if numeric_column in clean_df.columns:
            clean_df[numeric_column] = pd.to_numeric(clean_df[numeric_column], errors="coerce").round(2)

    if "Estado IA" in clean_df.columns:
        clean_df["Estado IA"] = clean_df["Estado IA"].apply(_shorten_ai_state)

    return clean_df


def _render_clean_ranking_table(display_df: pd.DataFrame, filtered_df: pd.DataFrame) -> None:
    """
    Render a product-style ranking table:
    - simplified main table;
    - full visible table in expander;
    - full technical table in expander.
    """

    st.markdown("### 🧭 Ranking resumido")
    st.caption(
        "Vista principal para decidir qué empresa revisar primero. "
        "La información técnica completa sigue disponible debajo."
    )

    clean_df = _build_clean_ranking_table(display_df, filtered_df)

    if clean_df.empty:
        st.info("No hay datos para mostrar en el ranking.")
        return

    column_config = {}

    if "Score" in clean_df.columns:
        column_config["Score"] = st.column_config.NumberColumn(
            "Score",
            format="%.2f",
            help="Prioridad cuantitativa de revisión. No es recomendación de inversión.",
        )

    if "Riesgo" in clean_df.columns:
        column_config["Riesgo"] = st.column_config.NumberColumn(
            "Riesgo",
            format="%.2f",
            help="Riesgo cuantitativo interno.",
        )

    if "Confianza" in clean_df.columns:
        column_config["Confianza"] = st.column_config.NumberColumn(
            "Confianza",
            format="%.2f",
            help="Confianza cuantitativa del ranking.",
        )

    if "Estado IA" in clean_df.columns:
        column_config["Estado IA"] = st.column_config.TextColumn(
            "Estado IA",
            help="Etiqueta resumida. El texto completo está en la tabla visible completa.",
            width="small",
        )

    st.dataframe(
        clean_df,
        use_container_width=True,
        hide_index=True,
        column_config=column_config,
    )

    st.info(
        "Siguiente paso: elige un ticker y abre `📄 Análisis empresa` "
        "para revisar la ficha completa y los outputs Fase 2."
    )

    with st.expander("Ver tabla visible completa", expanded=False):
        st.dataframe(
            display_df,
            use_container_width=True,
            hide_index=True,
        )

    with st.expander("Ver vista técnica completa", expanded=False):
        st.dataframe(
            filtered_df,
            use_container_width=True,
            hide_index=True,
        )


def _render_final_view(mode: str, top_n: int) -> pd.DataFrame:
    """
    Render final research view.

    Returns
    -------
    pandas.DataFrame
        Current final view dataframe, after UI filters.
    """

    st.subheader("🔎 Vista final de investigación")

    latest_run_id = get_latest_run_id(mode=mode)

    if latest_run_id is None:
        st.info("No hay datos para mostrar.")
        return pd.DataFrame()

    final_df = get_top_final_research_view(
        run_id=latest_run_id,
        mode=mode,
        top_n=top_n,
    )

    if final_df.empty:
        st.info("La vista final está vacía.")
        return final_df

    filtered_df = _apply_final_view_filters(final_df)

    final_summary = summarize_final_research_view(filtered_df)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Filas filtradas", final_summary["total_rows"])
    col2.metric("Con análisis OpenAI", final_summary["rows_with_openai_analysis"])
    col3.metric("Con feedback", final_summary["rows_with_manual_feedback"])
    col4.metric("Coste estimado", f"${final_summary['total_openai_estimated_cost']:.4f}")

    if filtered_df.empty:
        st.warning("No hay empresas que cumplan los filtros seleccionados.")
        return filtered_df

    display_df = _build_display_final_view(filtered_df)

    st.dataframe(
        display_df,
        use_container_width=True,
        hide_index=True,
    )

    _render_visual_dashboard(filtered_df)

    _render_direct_downloads(display_df, filtered_df)

    _render_company_detail(filtered_df, mode)

    with st.expander("Ver explicación OpenAI / feedback"):
        detail_columns = [
            "ticker",
            "company_name",
            "openai_reason_to_pass",
            "summary_thesis",
            "why_it_could_work",
            "why_it_could_fail",
            "feedback_label",
            "feedback_notes",
            "reviewed_by",
        ]
        available_detail_columns = [
            column for column in detail_columns if column in filtered_df.columns
        ]
        detail_df = filtered_df[available_detail_columns].copy()
        detail_df = detail_df.rename(
            columns={
                "ticker": "Ticker",
                "company_name": "Empresa",
                "openai_reason_to_pass": "Razón OpenAI",
                "summary_thesis": "Tesis",
                "why_it_could_work": "Por qué podría funcionar",
                "why_it_could_fail": "Por qué podría fallar",
                "feedback_label": "Feedback",
                "feedback_notes": "Notas feedback",
                "reviewed_by": "Revisado por",
            }
        )

        if "Razón OpenAI" in detail_df.columns:
            detail_df["Razón OpenAI"] = detail_df["Razón OpenAI"].apply(_short_openai_reason)

        if "Feedback" in detail_df.columns:
            detail_df["Feedback"] = detail_df["Feedback"].apply(_feedback_label)

        st.dataframe(detail_df.fillna(""), use_container_width=True, hide_index=True)

    with st.expander("Ver todas las columnas técnicas"):
        st.dataframe(filtered_df, use_container_width=True, hide_index=True)

    return filtered_df



def _get_latest_final_view_df(mode: str, top_n: int) -> pd.DataFrame:
    """
    Load latest final research view without rendering UI.

    Used by the tabbed UX so every tab can reuse the same underlying data
    without changing pipeline, OpenAI, database or scoring logic.
    """

    latest_run_id = get_latest_run_id(mode=mode)

    if latest_run_id is None:
        return pd.DataFrame()

    return get_top_final_research_view(
        run_id=latest_run_id,
        mode=mode,
        top_n=top_n,
    )


def _render_now_actions_card() -> None:
    """
    Render simple next-step guidance card.
    """

    st.markdown("### 🧭 Qué hacer ahora")
    st.info(
        "Flujo recomendado: 1) Ejecuta pipeline, 2) revisa ranking, "
        "3) abre la ficha de una empresa, 4) genera/consulta Fase 2, "
        "5) compara JSON generados y 6) registra feedback."
    )



def _sf_exec_phase2_json_summary() -> dict[str, Any]:
    """
    Build a compact summary from generated Phase 2 JSON files.

    This function only reads local JSON outputs. It never calls OpenAI.
    """

    summary: dict[str, Any] = {
        "companies": 0,
        "insufficient_data": 0,
        "avg_confidence": None,
        "avg_risk": None,
    }

    try:
        analyses_dir = Path(__file__).resolve().parent / "outputs" / "analyses"
        comparison_df = build_analysis_comparison_df(
            output_dir=analyses_dir,
            latest_only=True,
        )

        if comparison_df is None or comparison_df.empty:
            return summary

        summary["companies"] = int(len(comparison_df))

        if "final_category" in comparison_df.columns:
            categories = comparison_df["final_category"].fillna("").astype(str)
            summary["insufficient_data"] = int(
                categories.str.contains("Datos insuficientes", regex=False).sum()
            )

        if "confidence_score" in comparison_df.columns:
            avg_conf = pd.to_numeric(
                comparison_df["confidence_score"],
                errors="coerce",
            ).mean()
            if not pd.isna(avg_conf):
                summary["avg_confidence"] = float(avg_conf)

        if "risk_score" in comparison_df.columns:
            avg_risk = pd.to_numeric(
                comparison_df["risk_score"],
                errors="coerce",
            ).mean()
            if not pd.isna(avg_risk):
                summary["avg_risk"] = float(avg_risk)

    except Exception:
        # The dashboard must not break the app if the JSON folder is missing,
        # if an old file is malformed, or if the history module changes.
        return summary

    return summary


def _sf_exec_best_company_summary(final_df: pd.DataFrame) -> dict:
    """
    Return compact best-company information for the executive dashboard.

    This avoids long metric text being truncated in Streamlit.
    """

    empty = {
        "metric_label": "—",
        "caption": "Sin datos suficientes para seleccionar candidata.",
    }

    if final_df is None or final_df.empty:
        return empty

    working_df = final_df.copy()

    if "score_priority" in working_df.columns:
        working_df["_sf_score_priority_numeric"] = pd.to_numeric(
            working_df["score_priority"],
            errors="coerce",
        )
        working_df = working_df.sort_values(
            "_sf_score_priority_numeric",
            ascending=False,
        )

    first_row = working_df.iloc[0]
    ticker = _display_text(first_row.get("ticker"))
    company = _display_text(first_row.get("company_name"), default="")
    score = first_row.get("score_priority")

    score_text = ""

    if not _is_missing(score):
        try:
            score_text = f"{float(score):.2f}"
        except (TypeError, ValueError):
            score_text = str(score)

    if ticker != "—" and score_text:
        metric_label = f"{ticker} · {score_text}"
    else:
        metric_label = ticker

    caption_parts = []

    if company:
        caption_parts.append(company)

    if score_text:
        caption_parts.append(f"Score {score_text}")

    caption = " · ".join(caption_parts) if caption_parts else "Primera empresa por ranking cuantitativo."

    return {
        "metric_label": metric_label,
        "caption": caption,
    }


def _sf_exec_best_company_label(final_df: pd.DataFrame) -> str:
    """
    Backward-compatible label helper.
    """

    return _sf_exec_best_company_summary(final_df)["metric_label"]


def _render_executive_dashboard_cards(final_df: pd.DataFrame) -> None:
    """
    Render the Phase 4C executive dashboard.

    This is read-only and does not call OpenAI, write to SQLite, or change the
    quantitative pipeline.
    """

    st.markdown("### 🧭 Dashboard ejecutivo")
    st.caption("Lectura rápida del radar. No es recomendación de inversión.")

    if final_df is None or final_df.empty:
        st.info("No hay datos suficientes para el dashboard ejecutivo.")
        return

    phase2_summary = _sf_exec_phase2_json_summary()
    final_summary = summarize_final_research_view(final_df)

    best_company_summary = _sf_exec_best_company_summary(final_df)
    best_company = best_company_summary.get("metric_label", "—")
    rows_with_openai = int(final_summary.get("rows_with_openai_analysis", 0))
    rows_with_feedback = int(final_summary.get("rows_with_manual_feedback", 0))
    estimated_cost = float(final_summary.get("total_openai_estimated_cost", 0.0) or 0.0)

    phase2_companies = int(phase2_summary.get("companies", 0) or 0)
    insufficient_data = int(phase2_summary.get("insufficient_data", 0) or 0)
    avg_confidence = phase2_summary.get("avg_confidence")
    avg_risk = phase2_summary.get("avg_risk")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric(
            "Mejor candidata a revisar",
            best_company,
            help="Primera empresa por ranking cuantitativo. No implica compra.",
        )
        st.caption(best_company_summary.get("caption", ""))
    col2.metric(
        "Con análisis IA",
        rows_with_openai,
        help="Filas del ranking con análisis IA registrado.",
    )
    col3.metric(
        "Outputs Fase 2",
        phase2_companies,
        help="Empresas con JSON estructurado generado en outputs/analyses.",
    )
    col4.metric(
        "Datos insuficientes",
        insufficient_data,
        help="Empresas clasificadas como datos insuficientes en Fase 2.",
    )

    col5, col6, col7, col8 = st.columns(4)

    col5.metric(
        "Confianza media Fase 2",
        "—" if avg_confidence is None else f"{float(avg_confidence):.1f}/10",
    )
    col6.metric(
        "Riesgo medio Fase 2",
        "—" if avg_risk is None else f"{float(avg_risk):.1f}/10",
        help="En riesgo, más bajo es mejor.",
    )
    col7.metric(
        "Con feedback",
        rows_with_feedback,
        help="Empresas con feedback manual en la vista actual.",
    )
    col8.metric(
        "Coste IA acumulado",
        f"${estimated_cost:.4f}",
        help="Coste registrado en la vista final actual.",
    )

    next_action = "Revisa el ranking y abre la ficha de la mejor candidata en la pestaña Análisis empresa."

    if phase2_companies == 0:
        next_action = "Genera primero outputs Fase 2 para Top 1 o Top 3 antes de comparar empresas."
    elif insufficient_data > 0:
        next_action = "Revisa las empresas con datos insuficientes en la pestaña Comparar empresas."
    elif rows_with_openai == 0:
        next_action = "Ejecuta un análisis IA controlado para Top 1 antes de escalar a más empresas."

    st.info(f"**Próxima acción recomendada:** {next_action}")


def _render_dashboard_tab(mode: str, top_n: int) -> None:
    """
    Render Dashboard tab.

    Contains the executive overview, execution controls, latest run summary and
    high-level charts.
    """

    _render_now_actions_card()

    final_df = _get_latest_final_view_df(mode=mode, top_n=top_n)

    if not final_df.empty:
        _render_executive_dashboard_cards(final_df)
        st.divider()

    _render_run_controls(mode)
    st.divider()

    _render_run_summary(mode)
    st.divider()

    if final_df.empty:
        st.info("No hay datos para el dashboard. Ejecuta primero el pipeline cuantitativo.")
        return

    _render_visual_dashboard(final_df)


def _render_ranking_tab(mode: str, top_n: int) -> pd.DataFrame:
    """
    Render ranking tab with filters, table and downloads.

    Returns the filtered dataframe so the main flow can keep feedback compatible.
    """

    st.subheader("🔎 Ranking de investigación")

    latest_run_id = get_latest_run_id(mode=mode)

    if latest_run_id is None:
        st.info("No hay datos para mostrar.")
        return pd.DataFrame()

    final_df = get_top_final_research_view(
        run_id=latest_run_id,
        mode=mode,
        top_n=top_n,
    )

    if final_df.empty:
        st.info("La vista final está vacía.")
        return final_df

    filtered_df = _apply_final_view_filters(final_df)
    final_summary = summarize_final_research_view(filtered_df)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Filas filtradas", final_summary["total_rows"])
    col2.metric("Con análisis OpenAI", final_summary["rows_with_openai_analysis"])
    col3.metric("Con feedback", final_summary["rows_with_manual_feedback"])
    col4.metric("Coste estimado", f"${final_summary['total_openai_estimated_cost']:.4f}")

    if filtered_df.empty:
        st.warning("No hay empresas que cumplan los filtros seleccionados.")
        return filtered_df

    display_df = _build_display_final_view(filtered_df)

    _render_clean_ranking_table(display_df, filtered_df)

    _render_direct_downloads(display_df, filtered_df)

    with st.expander("Ver explicación OpenAI / feedback", expanded=False):
        detail_columns = [
            "ticker",
            "company_name",
            "openai_reason_to_pass",
            "summary_thesis",
            "why_it_could_work",
            "why_it_could_fail",
            "feedback_label",
            "feedback_notes",
            "reviewed_by",
        ]
        available_detail_columns = [
            column for column in detail_columns if column in filtered_df.columns
        ]
        detail_df = filtered_df[available_detail_columns].copy()
        detail_df = detail_df.rename(
            columns={
                "ticker": "Ticker",
                "company_name": "Empresa",
                "openai_reason_to_pass": "Razón OpenAI",
                "summary_thesis": "Tesis",
                "why_it_could_work": "Por qué podría funcionar",
                "why_it_could_fail": "Por qué podría fallar",
                "feedback_label": "Feedback",
                "feedback_notes": "Notas feedback",
                "reviewed_by": "Revisado por",
            }
        )

        if "Razón OpenAI" in detail_df.columns:
            detail_df["Razón OpenAI"] = detail_df["Razón OpenAI"].apply(_short_openai_reason)

        if "Feedback" in detail_df.columns:
            detail_df["Feedback"] = detail_df["Feedback"].apply(_feedback_label)

        st.dataframe(detail_df.fillna(""), use_container_width=True, hide_index=True)

    with st.expander("Ver todas las columnas técnicas", expanded=False):
        st.dataframe(filtered_df, use_container_width=True, hide_index=True)

    return filtered_df


def _render_company_analysis_tab(mode: str, top_n: int) -> pd.DataFrame:
    """
    Render individual company analysis tab.

    This keeps the existing company detail, Phase 2 outputs, legacy report
    and feedback flow intact.
    """

    final_df = _get_latest_final_view_df(mode=mode, top_n=top_n)

    if final_df.empty:
        st.info("No hay empresas disponibles. Ejecuta primero el pipeline cuantitativo.")
        return final_df

    _render_company_detail(final_df, mode)
    return final_df



def _sf4e_load_analysis_history_df() -> pd.DataFrame:
    """
    Load all structured JSON analyses from outputs/analyses.

    This does not call OpenAI.
    """

    try:
        analyses_dir = Path(__file__).resolve().parent / "outputs" / "analyses"
        history_df = build_analysis_comparison_df(
            output_dir=analyses_dir,
            latest_only=False,
        )

        if history_df is None:
            return pd.DataFrame()

        return history_df.copy()

    except Exception as exc:
        st.warning(f"No se pudo cargar el histórico JSON: {exc}")
        return pd.DataFrame()


def _sf4e_pick_column(df: pd.DataFrame, candidates: list[str]) -> str | None:
    """
    Return first existing column name.
    """

    if df is None or df.empty:
        return None

    for column in candidates:
        if column in df.columns:
            return column

    return None


def _sf4e_prepare_history_display(df: pd.DataFrame) -> pd.DataFrame:
    """
    Prepare a readable company history table.
    """

    if df is None or df.empty:
        return pd.DataFrame()

    display_df = df.copy()

    # Normalize likely fields.
    rename_map = {
        "ticker": "Ticker",
        "company_name": "Empresa",
        "analysis_date": "Fecha análisis",
        "final_category": "Categoría",
        "confidence_level": "Confianza",
        "confidence_score": "Score confianza",
        "risk_score": "Riesgo",
        "business_quality_score": "Calidad negocio",
        "financial_health_score": "Salud financiera",
        "growth_score": "Crecimiento",
        "valuation_score": "Valoración",
        "moat_score": "Moat",
        "evidence_quality_score": "Evidencia",
        "data_freshness_score": "Actualidad datos",
        "output_id": "Output",
    }

    for old, new in rename_map.items():
        if old in display_df.columns and new not in display_df.columns:
            display_df[new] = display_df[old]

    # Try to make date readable and sortable.
    date_col = _sf4e_pick_column(display_df, ["Fecha análisis", "created_at", "analysis_date"])

    if date_col:
        display_df["_sf4e_date_sort"] = pd.to_datetime(
            display_df[date_col],
            errors="coerce",
            utc=True,
        )
        display_df = display_df.sort_values("_sf4e_date_sort", ascending=False)

    preferred = [
        "Fecha análisis",
        "Ticker",
        "Empresa",
        "Categoría",
        "Confianza",
        "Score confianza",
        "Riesgo",
        "Calidad negocio",
        "Salud financiera",
        "Crecimiento",
        "Valoración",
        "Moat",
        "Evidencia",
        "Actualidad datos",
        "Output",
    ]

    available = [column for column in preferred if column in display_df.columns]

    if not available:
        return display_df

    result = display_df[available].copy()

    for numeric_column in [
        "Score confianza",
        "Riesgo",
        "Calidad negocio",
        "Salud financiera",
        "Crecimiento",
        "Valoración",
        "Moat",
        "Evidencia",
        "Actualidad datos",
    ]:
        if numeric_column in result.columns:
            result[numeric_column] = pd.to_numeric(result[numeric_column], errors="coerce").round(2)

    return result


def _sf4e_render_delta_summary(company_history_df: pd.DataFrame) -> None:
    """
    Render old vs latest comparison for selected ticker.

    Important:
    - For normal scores, higher is better.
    - For risk_score, lower is better.
    """

    if company_history_df is None or company_history_df.empty:
        return

    date_col = _sf4e_pick_column(company_history_df, ["analysis_date", "Fecha análisis", "created_at"])

    working_df = company_history_df.copy()

    if date_col:
        working_df["_sf4e_date_sort"] = pd.to_datetime(
            working_df[date_col],
            errors="coerce",
            utc=True,
        )
        working_df = working_df.sort_values("_sf4e_date_sort", ascending=True)

    if len(working_df) < 2:
        st.info("Solo hay un análisis para este ticker. Cuando generes más análisis, aquí verás la evolución.")
        return

    first = working_df.iloc[0]
    last = working_df.iloc[-1]

    def read_numeric(row: pd.Series, column: str) -> float | None:
        value = pd.to_numeric(pd.Series([row.get(column)]), errors="coerce").iloc[0]

        if pd.isna(value):
            return None

        return float(value)

    def score_metric(column: str, *, inverse: bool = False) -> tuple[str, str, str]:
        """
        Return current value, delta label and delta color.

        inverse=True is used for risk: lower is better.
        """

        old = read_numeric(first, column)
        new = read_numeric(last, column)

        if old is None or new is None:
            return "—", "No comparable", "off"

        raw_delta = new - old

        if abs(raw_delta) < 0.05:
            return f"{new:.1f}/10", "sin cambio", "off"

        if inverse:
            # Risk up is worse; risk down is better.
            if raw_delta > 0:
                return f"{new:.1f}/10", f"+{raw_delta:.1f} peor", "inverse"
            return f"{new:.1f}/10", f"{raw_delta:.1f} mejor", "normal"

        # Normal scores: up is better; down is worse.
        if raw_delta > 0:
            return f"{new:.1f}/10", f"+{raw_delta:.1f} mejor", "normal"

        return f"{new:.1f}/10", f"{raw_delta:.1f} peor", "inverse"

    confidence_value, confidence_delta, confidence_color = score_metric("confidence_score")
    risk_value, risk_delta, risk_color = score_metric("risk_score", inverse=True)
    quality_value, quality_delta, quality_color = score_metric("business_quality_score")
    moat_value, moat_delta, moat_color = score_metric("moat_score")

    col1, col2, col3, col4 = st.columns(4)

    col1.metric(
        "Confianza actual",
        confidence_value,
        confidence_delta,
        delta_color=confidence_color,
    )

    col2.metric(
        "Riesgo actual",
        risk_value,
        risk_delta,
        delta_color=risk_color,
        help="En riesgo, más bajo es mejor. Si sube, empeora.",
    )

    col3.metric(
        "Calidad negocio actual",
        quality_value,
        quality_delta,
        delta_color=quality_color,
    )

    col4.metric(
        "Moat actual",
        moat_value,
        moat_delta,
        delta_color=moat_color,
    )

    old_category = first.get("final_category", "—")
    new_category = last.get("final_category", "—")

    if str(old_category) != str(new_category):
        st.warning(f"Cambio de categoría: {old_category} → {new_category}")
    else:
        st.success(f"Categoría estable: {new_category}")


def _sf4e_render_history_charts(company_history_df: pd.DataFrame) -> None:
    """
    Render evolution charts using Streamlit native charts.

    Phase 4E.2:
    - Main chart: only scores where higher is better.
    - Separate risk chart: risk_score, where lower is better.
    """

    if company_history_df is None or company_history_df.empty:
        return

    if len(company_history_df) < 2:
        return

    date_col = _sf4e_pick_column(company_history_df, ["analysis_date", "Fecha análisis", "created_at"])

    chart_df = company_history_df.copy()

    if date_col:
        chart_df["_fecha"] = pd.to_datetime(chart_df[date_col], errors="coerce")
        chart_df = chart_df.sort_values("_fecha")
    else:
        chart_df = chart_df.reset_index(drop=True)

    chart_index = [f"Análisis {idx}" for idx in range(1, len(chart_df) + 1)]

    positive_score_columns = {
        "confidence_score": "Confianza",
        "business_quality_score": "Calidad negocio",
        "moat_score": "Moat",
        "evidence_quality_score": "Evidencia",
        "data_freshness_score": "Actualidad datos",
        "financial_health_score": "Salud financiera",
        "growth_score": "Crecimiento",
        "valuation_score": "Valoración",
    }

    positive_scores = {}

    for source_col, label in positive_score_columns.items():
        if source_col in chart_df.columns:
            values = pd.to_numeric(chart_df[source_col], errors="coerce").reset_index(drop=True)
            if not values.dropna().empty:
                positive_scores[label] = values

    if positive_scores:
        st.markdown("##### Scores principales")
        st.caption("En este gráfico, subir suele ser mejor.")
        positive_plot_df = pd.DataFrame(positive_scores)
        positive_plot_df.index = chart_index
        st.line_chart(positive_plot_df, use_container_width=True)
    else:
        st.info("No hay scores positivos suficientes para graficar evolución.")

    if "risk_score" in chart_df.columns:
        risk_values = pd.to_numeric(chart_df["risk_score"], errors="coerce").reset_index(drop=True)

        if not risk_values.dropna().empty:
            st.markdown("##### Riesgo")
            st.caption("En riesgo, más bajo es mejor. Si la línea sube, el perfil de riesgo empeora.")
            risk_plot_df = pd.DataFrame({"Riesgo": risk_values})
            risk_plot_df.index = chart_index
            st.line_chart(risk_plot_df, use_container_width=True)
        else:
            st.info("No hay datos de riesgo suficientes para graficar evolución.")
    else:
        st.info("No hay columna `risk_score` disponible para graficar riesgo.")

    with st.expander("Ver fechas de cada análisis", expanded=False):
        date_display = chart_df.copy()

        preferred = [
            "analysis_date",
            "ticker",
            "company_name",
            "final_category",
            "confidence_score",
            "risk_score",
            "business_quality_score",
            "moat_score",
            "output_id",
        ]

        available_cols = [column for column in preferred if column in date_display.columns]

        if available_cols:
            st.dataframe(date_display[available_cols], use_container_width=True, hide_index=True)
        else:
            st.dataframe(date_display, use_container_width=True, hide_index=True)


def _render_company_json_history_section() -> None:
    """
    Render Phase 4E: per-company historical evolution from saved JSON files.
    """

    st.markdown("### 📈 Histórico de análisis por empresa")
    st.caption(
        "Evolución basada en los JSON guardados en `outputs/analyses`. "
        "No llama a OpenAI y no gasta tokens."
    )

    history_df = _sf4e_load_analysis_history_df()

    if history_df.empty:
        st.info("No hay JSON históricos todavía. Genera outputs Fase 2 para empezar a crear histórico.")
        return

    ticker_col = _sf4e_pick_column(history_df, ["ticker", "Ticker"])

    if ticker_col is None:
        st.warning("No se encuentra columna ticker en el histórico JSON.")
        return

    tickers = sorted(
        [
            str(ticker)
            for ticker in history_df[ticker_col].dropna().unique().tolist()
            if str(ticker).strip()
        ]
    )

    if not tickers:
        st.info("No hay tickers disponibles en el histórico JSON.")
        return

    selected_ticker = st.selectbox(
        "Seleccionar empresa para ver histórico",
        options=tickers,
        index=0,
        key="sf4e_selected_history_ticker",
    )

    company_history_df = history_df[
        history_df[ticker_col].astype(str).str.upper() == selected_ticker.upper()
    ].copy()

    total_analyses = len(company_history_df)

    latest_only_df = build_analysis_comparison_df(
        output_dir=Path(__file__).resolve().parent / "outputs" / "analyses",
        latest_only=True,
    )

    col1, col2, col3 = st.columns(3)
    col1.metric("Análisis guardados", total_analyses)
    col2.metric("Tickers con histórico", len(tickers))
    col3.metric(
        "Estado",
        "Histórico suficiente" if total_analyses >= 2 else "Solo 1 análisis",
    )

    _sf4e_render_delta_summary(company_history_df)

    st.markdown("#### Evolución histórica")
    _sf4e_render_history_charts(company_history_df)

    st.markdown("#### Tabla histórica del ticker")
    display_history = _sf4e_prepare_history_display(company_history_df)
    st.dataframe(display_history, use_container_width=True, hide_index=True)

    with st.expander("Ver histórico JSON completo", expanded=False):
        complete_display = _sf4e_prepare_history_display(history_df)
        st.dataframe(complete_display, use_container_width=True, hide_index=True)

    csv_bytes = display_history.to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        label="Descargar histórico del ticker CSV",
        data=csv_bytes,
        file_name=f"scout_finance_historico_{selected_ticker}.csv",
        mime="text/csv",
        use_container_width=True,
    )



def _render_history_technical_tab(mode: str, top_n: int) -> None:
    """
    Render technical/history tab.
    """

    st.subheader("🧾 Histórico / técnico")

    _render_company_json_history_section()

    st.divider()

    latest_run_id = get_latest_run_id(mode=mode)

    runs_df = list_runs(mode=mode, limit=25)

    with st.expander("Runs recientes", expanded=True):
        if runs_df.empty:
            st.info("No hay runs recientes.")
        else:
            st.dataframe(runs_df, use_container_width=True, hide_index=True)

    if latest_run_id is None:
        st.info("No hay run activo para mostrar tablas técnicas.")
        return

    with st.expander("Cost log", expanded=False):
        cost_df = load_cost_log(run_id=latest_run_id, mode=mode)

        if cost_df.empty:
            st.info("No hay costes registrados.")
        else:
            st.dataframe(cost_df, use_container_width=True, hide_index=True)

    with st.expander("Feedback manual guardado", expanded=False):
        feedback_df = load_manual_feedback(run_id=latest_run_id, mode=mode)

        if feedback_df.empty:
            st.info("No hay feedback guardado.")
        else:
            st.dataframe(feedback_df, use_container_width=True, hide_index=True)

    with st.expander("Vista técnica final", expanded=False):
        final_df = _get_latest_final_view_df(mode=mode, top_n=top_n)

        if final_df.empty:
            st.info("No hay vista final disponible.")
        else:
            st.dataframe(final_df, use_container_width=True, hide_index=True)


def _sf4f_file_count(path: Path, pattern: str = "*") -> int:
    """
    Count files safely.
    """

    try:
        if not path.exists():
            return 0
        return len([item for item in path.glob(pattern) if item.is_file()])
    except Exception:
        return 0


def _sf4f_latest_files(path: Path, limit: int = 8) -> pd.DataFrame:
    """
    Return latest files from a folder as dataframe.
    """

    rows = []

    try:
        if not path.exists():
            return pd.DataFrame()

        files = [item for item in path.iterdir() if item.is_file()]
        files = sorted(files, key=lambda item: item.stat().st_mtime, reverse=True)

        for item in files[:limit]:
            rows.append(
                {
                    "archivo": item.name,
                    "tipo": item.suffix.lower().replace(".", "") or "sin extensión",
                    "tamaño_kb": round(item.stat().st_size / 1024, 1),
                    "modificado": datetime.fromtimestamp(item.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                }
            )

    except Exception:
        return pd.DataFrame()

    return pd.DataFrame(rows)


def _sf4f_status_badge(ok: bool, label_ok: str = "OK", label_bad: str = "Revisar") -> str:
    """
    Compact status string.
    """

    return f"✅ {label_ok}" if ok else f"⚠️ {label_bad}"



def _sf4f_yes_no(value) -> str:
    """
    Convert booleans to Spanish-readable labels.
    """

    return "Sí" if bool(value) else "No"


def _sf4f_system_ready_status(status: dict, analyses_dir: Path) -> tuple[str, str]:
    """
    Return global system readiness label and explanation.

    This is a diagnostic helper only. It does not execute OpenAI.
    """

    has_outputs_dir = analyses_dir.exists()
    has_json = _sf4f_file_count(analyses_dir, "*.json") > 0
    openai_enabled = bool(status.get("enable_openai"))
    api_key_defined = bool(status.get("api_key_defined"))
    api_key_ok = not bool(status.get("api_key_looks_placeholder"))

    if openai_enabled and api_key_defined and api_key_ok and has_outputs_dir:
        if has_json:
            return (
                "✅ Sistema listo",
                "Configuración principal correcta y outputs Fase 2 disponibles.",
            )

        return (
            "✅ Listo para generar análisis",
            "OpenAI parece configurado correctamente, pero aún hay pocos outputs Fase 2.",
        )

    problems = []

    if not has_outputs_dir:
        problems.append("crear o revisar `outputs/analyses`")

    if not openai_enabled:
        problems.append("activar OpenAI si quieres generar nuevos análisis")

    if not api_key_defined:
        problems.append("definir API key")

    if not api_key_ok:
        problems.append("revisar API key porque parece placeholder")

    if not problems:
        problems.append("revisar configuración general")

    return (
        "⚠️ Revisar configuración",
        "Pendiente: " + ", ".join(problems) + ".",
    )


def _sf4f_file_type_summary(path: Path) -> pd.DataFrame:
    """
    Summarize generated files by type.
    """

    rows = []

    try:
        if not path.exists():
            return pd.DataFrame()

        files = [item for item in path.iterdir() if item.is_file()]
        type_counts = {}

        for item in files:
            suffix = item.suffix.lower().replace(".", "") or "sin extensión"
            type_counts[suffix] = type_counts.get(suffix, 0) + 1

        for suffix, count in sorted(type_counts.items(), key=lambda pair: pair[0]):
            rows.append({"tipo": suffix, "archivos": count})

    except Exception:
        return pd.DataFrame()

    return pd.DataFrame(rows)



def _render_settings_tab() -> None:
    """
    Render settings/status tab.

    Phase 4F:
    Clean technical panel with configuration, paths, costs and system checks.
    This is read-only; operational configuration remains in the sidebar/.env.
    """

    st.subheader("⚙️ Ajustes / panel técnico")
    st.caption(
        "Panel de diagnóstico y configuración visible. No ejecuta OpenAI y no modifica archivos."
    )

    project_root = Path(__file__).resolve().parent
    outputs_dir = project_root / "outputs"
    analyses_dir = outputs_dir / "analyses"
    data_dir = project_root / "data"
    demo_dir = data_dir / "demo"
    env_path = project_root / ".env"

    status = get_openai_status()
    estimated_cost = _estimate_openai_run_cost(
        int(status["max_companies_per_run"])
    )

    system_label, system_detail = _sf4f_system_ready_status(status, analyses_dir)

    st.markdown("### 🧭 Estado general")
    st.info(f"**{system_label}** — {system_detail}")

    st.markdown("### 🧠 Estado OpenAI")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("OpenAI activo", _sf4f_yes_no(status.get("enable_openai", False)))
    col2.metric("API key definida", _sf4f_yes_no(status.get("api_key_defined", False)))
    col3.metric("Modelo ligero", str(status.get("model_light", "—")))
    col4.metric("Modelo fuerte", str(status.get("model_strong", "—")))

    with st.expander("Ver configuración OpenAI completa", expanded=False):
        st.json(status)

    st.markdown("### 💰 Control de costes")

    col5, col6, col7, col8 = st.columns(4)
    col5.metric("Empresas IA/run", int(estimated_cost["number_of_companies"]))
    col6.metric(
        "Tokens entrada/run",
        f"{int(estimated_cost['estimated_input_tokens']):,}",
    )
    col7.metric(
        "Tokens salida/run",
        f"{int(estimated_cost['estimated_output_tokens']):,}",
    )
    col8.metric("Coste estimado/run", f"${estimated_cost['estimated_total_cost']:.4f}")

    budget_col1, budget_col2 = st.columns(2)
    budget_col1.metric("Presupuesto diario", f"${float(status.get('daily_budget_usd', 0.0)):.2f}")
    budget_col2.metric("Presupuesto mensual", f"${float(status.get('monthly_budget_usd', 0.0)):.2f}")

    st.info(
        "Los costes son estimaciones de control. El coste real puede variar según tokens reales y modelo usado."
    )

    st.markdown("### 📁 Rutas y outputs")

    path_col1, path_col2, path_col3 = st.columns(3)
    path_col1.metric("JSON análisis", _sf4f_file_count(analyses_dir, "*.json"))
    path_col2.metric("Markdown análisis", _sf4f_file_count(analyses_dir, "*.md"))
    path_col3.metric("HTML ejecutivos", _sf4f_file_count(analyses_dir, "*executive_card.html"))

    path_rows = [
        {"Elemento": "Raíz proyecto", "Ruta": str(project_root), "Estado": _sf4f_status_badge(project_root.exists())},
        {"Elemento": "outputs", "Ruta": str(outputs_dir), "Estado": _sf4f_status_badge(outputs_dir.exists())},
        {"Elemento": "outputs/analyses", "Ruta": str(analyses_dir), "Estado": _sf4f_status_badge(analyses_dir.exists())},
        {"Elemento": "data/demo", "Ruta": str(demo_dir), "Estado": _sf4f_status_badge(demo_dir.exists())},
        {"Elemento": ".env", "Ruta": str(env_path), "Estado": _sf4f_status_badge(env_path.exists(), "Existe", "No encontrado")},
    ]

    with st.expander("Ver rutas del proyecto", expanded=False):
        st.dataframe(pd.DataFrame(path_rows), use_container_width=True, hide_index=True)

    st.markdown("### 🧾 Últimos archivos generados")

    latest_files_df = _sf4f_latest_files(analyses_dir, limit=10)

    if latest_files_df.empty:
        st.info("No hay archivos generados en outputs/analyses.")
    else:
        st.dataframe(latest_files_df, use_container_width=True, hide_index=True)

        file_type_df = _sf4f_file_type_summary(analyses_dir)
        if not file_type_df.empty:
            with st.expander("Ver resumen por tipo de archivo", expanded=False):
                st.dataframe(file_type_df, use_container_width=True, hide_index=True)

    st.markdown("### 🧪 Checks rápidos del sistema")

    checks = []

    checks.append(
        {
            "Check": "Carpeta outputs/analyses existe",
            "Estado": _sf4f_status_badge(analyses_dir.exists()),
            "Detalle": str(analyses_dir),
        }
    )

    checks.append(
        {
            "Check": "Hay JSON Fase 2",
            "Estado": _sf4f_status_badge(_sf4f_file_count(analyses_dir, "*.json") > 0, "Sí", "No"),
            "Detalle": f"{_sf4f_file_count(analyses_dir, '*.json')} JSON encontrados",
        }
    )

    checks.append(
        {
            "Check": "Hay HTML ejecutivos",
            "Estado": _sf4f_status_badge(_sf4f_file_count(analyses_dir, '*executive_card.html') > 0, "Sí", "No"),
            "Detalle": f"{_sf4f_file_count(analyses_dir, '*executive_card.html')} HTML encontrados",
        }
    )

    checks.append(
        {
            "Check": "OpenAI habilitado",
            "Estado": _sf4f_status_badge(bool(status.get("enable_openai")), "Activado", "Desactivado"),
            "Detalle": "Controlado desde .env/configuración.",
        }
    )

    checks.append(
        {
            "Check": "API key definida",
            "Estado": _sf4f_status_badge(bool(status.get("api_key_defined")), "Definida", "No definida"),
            "Detalle": "No se muestra la clave por seguridad.",
        }
    )

    checks.append(
        {
            "Check": "API key no parece placeholder",
            "Estado": _sf4f_status_badge(not bool(status.get("api_key_looks_placeholder")), "Correcto", "Parece placeholder"),
            "Detalle": "Si parece placeholder, OpenAI real fallará.",
        }
    )

    st.dataframe(pd.DataFrame(checks), use_container_width=True, hide_index=True)

    with st.expander("Notas técnicas", expanded=False):
        st.markdown(
            """
            - Esta pestaña es de lectura: no escribe en disco.
            - La configuración real sigue en `.env` y en la barra lateral.
            - Los outputs Fase 2 se guardan en `outputs/analyses`.
            - El histórico y la comparativa visual leen JSON ya generados.
            - Si algo falla en OpenAI, revisa primero `enable_openai`, `api_key_defined`, modelo y presupuesto.
            """
        )



def _render_feedback_form(mode: str, final_df: pd.DataFrame) -> None:
    """
    Render feedback form.
    """

    st.subheader("✍️ Feedback manual")

    latest_run_id = get_latest_run_id(mode=mode)

    if latest_run_id is None or final_df.empty:
        st.info("No hay señales sobre las que registrar feedback.")
        return

    tickers = final_df["ticker"].dropna().astype(str).unique().tolist()
    labels = get_valid_feedback_labels()

    label_display_map = {FEEDBACK_LABELS.get(label, label): label for label in labels}
    label_display_options = list(label_display_map.keys())

    col1, col2 = st.columns(2)

    with col1:
        ticker = st.selectbox("Ticker", options=tickers)

    with col2:
        default_label = "Investigar más" if "Investigar más" in label_display_options else label_display_options[0]
        default_index = label_display_options.index(default_label)
        selected_label_display = st.selectbox(
            "Etiqueta",
            options=label_display_options,
            index=default_index,
        )
        feedback_label = label_display_map[selected_label_display]

    notes = st.text_area("Notas", placeholder="Motivo del feedback...")
    reviewed_by = st.text_input("Revisado por", value="Iker")

    if st.button("Guardar feedback"):
        feedback_id = _safe_run_action(
            "guardar feedback",
            add_manual_feedback_by_ticker,
            ticker=ticker,
            feedback_label=feedback_label,
            notes=notes,
            reviewed_by=reviewed_by,
            run_id=latest_run_id,
            mode=mode,
        )

        if feedback_id:
            st.success(f"Feedback guardado. ID: {feedback_id}")
            st.rerun()




def _sf5g_project_root() -> Path:
    """
    Return project root for app.py.
    """

    return Path(__file__).resolve().parent


def _sf5g_load_stage3_candidates(limit: int | None = None) -> pd.DataFrame:
    """
    Load Stage 3 candidates from outputs/scouting/top_100_candidates.csv.

    This does not call OpenAI.
    """

    path = _sf5g_project_root() / "outputs" / "scouting" / "top_100_candidates.csv"

    if not path.exists():
        return pd.DataFrame()

    try:
        df = pd.read_csv(path)
    except Exception:
        return pd.DataFrame()

    if df.empty:
        return df

    if "final_stage3_score" in df.columns:
        df["final_stage3_score"] = pd.to_numeric(df["final_stage3_score"], errors="coerce")
        df = df.sort_values("final_stage3_score", ascending=False)

    if limit is not None:
        df = df.head(limit)

    return df.reset_index(drop=True)


def _sf5g_count_candidate_file(filename: str) -> int:
    """
    Count rows of an output/scouting CSV file safely.
    """

    path = _sf5g_project_root() / "outputs" / "scouting" / filename

    if not path.exists():
        return 0

    try:
        return int(len(pd.read_csv(path)))
    except Exception:
        return 0


def _sf5g_prepare_stage3_display_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    Prepare a readable dataframe for Stage 3 candidates.
    """

    if df.empty:
        return df

    display = df.copy()

    rename_map = {
        "ticker": "Ticker",
        "name": "Empresa",
        "sector": "Sector",
        "industry": "Industria",
        "country": "País",
        "market_cap": "Market cap",
        "final_stage3_score": "Score final",
        "stage3_category": "Categoría Stage 3",
        "business_quality_score": "Calidad negocio",
        "financial_health_score": "Salud financiera",
        "growth_score": "Crecimiento",
        "valuation_score": "Valoración",
        "risk_score": "Riesgo",
        "moat_proxy_score": "Moat proxy",
        "momentum_score": "Momentum",
        "liquidity_score": "Liquidez",
        "data_quality_score": "Calidad datos",
    }

    for old, new in rename_map.items():
        if old in display.columns and new not in display.columns:
            display[new] = display[old]

    preferred = [
        "Ticker",
        "Empresa",
        "Score final",
        "Categoría Stage 3",
        "Sector",
        "Industria",
        "País",
        "Market cap",
        "Calidad negocio",
        "Salud financiera",
        "Crecimiento",
        "Valoración",
        "Riesgo",
        "Moat proxy",
        "Momentum",
        "Liquidez",
        "Calidad datos",
    ]

    available = [column for column in preferred if column in display.columns]
    result = display[available].copy() if available else display.copy()

    numeric_columns = [
        "Score final",
        "Market cap",
        "Calidad negocio",
        "Salud financiera",
        "Crecimiento",
        "Valoración",
        "Riesgo",
        "Moat proxy",
        "Momentum",
        "Liquidez",
        "Calidad datos",
    ]

    for column in numeric_columns:
        if column in result.columns:
            result[column] = pd.to_numeric(result[column], errors="coerce").round(2)

    return result


def _sf5g_render_stage3_candidates_cards(df: pd.DataFrame) -> None:
    """
    Render compact top candidate cards.
    """

    if df.empty:
        return

    top = df.head(3).copy()

    cols = st.columns(min(3, len(top)))

    for idx, (_, row) in enumerate(top.iterrows()):
        ticker = row.get("ticker", "—")
        name = row.get("name", "—")
        score = row.get("final_stage3_score", "—")
        category = row.get("stage3_category", "—")
        risk = row.get("risk_score", "—")
        quality = row.get("business_quality_score", "—")

        with cols[idx]:
            st.markdown(
                f"""
                <div style="
                    border:1px solid #e5e7eb;
                    border-radius:14px;
                    padding:14px;
                    background:#ffffff;
                    min-height:150px;
                ">
                    <div style="font-size:13px;color:#6b7280;">{ticker}</div>
                    <div style="font-size:18px;font-weight:700;margin-bottom:6px;">{name}</div>
                    <div style="font-size:24px;font-weight:800;">{score}</div>
                    <div style="font-size:13px;color:#374151;margin-bottom:8px;">{category}</div>
                    <div style="font-size:12px;color:#6b7280;">Calidad: {quality} · Riesgo: {risk}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )


def _render_stage3_candidates_tab() -> None:
    """
    Render Stage 3 candidates generated by the global funnel.

    Phase 5G:
    Optional visual tab. Does not replace the existing ranking.
    """

    st.subheader("🧭 Candidatos Stage 3")
    st.caption(
        "Vista del embudo global. No es recomendación de inversión. "
        "No llama a OpenAI, no sustituye el ranking actual y no modifica outputs."
    )

    scouting_dir = _sf5g_project_root() / "outputs" / "scouting"
    top100_path = scouting_dir / "top_100_candidates.csv"

    if not top100_path.exists():
        st.info(
            "Todavía no hay candidatos Stage 3. "
            "Ejecuta Fase 5E para generar `outputs/scouting/top_100_candidates.csv`."
        )

        with st.expander("Comandos para generar candidatos Stage 3", expanded=False):
            st.code(
                "./.venv/Scripts/python.exe -m src.load_global_universe\n"
                "./.venv/Scripts/python.exe -m src.run_stage1_filter\n"
                "./.venv/Scripts/python.exe -m src.enrich_stage1_demo_financials\n"
                "./.venv/Scripts/python.exe -m src.run_stage2_filter\n"
                "./.venv/Scripts/python.exe -m src.enrich_stage2_demo_scoring_inputs\n"
                "./.venv/Scripts/python.exe -m src.run_stage3_scoring",
                language="powershell",
            )
        return

    candidates_df = _sf5g_load_stage3_candidates(limit=100)

    if candidates_df.empty:
        st.warning("El archivo `top_100_candidates.csv` existe, pero está vacío.")
        return

    top20_count = _sf5g_count_candidate_file("top_20_deep_research.csv")
    top50_count = _sf5g_count_candidate_file("top_50_watchlist.csv")
    top100_count = _sf5g_count_candidate_file("top_100_candidates.csv")
    recoverable_count = _sf5g_count_candidate_file("top_recoverable_candidates.csv")

    avg_score = None

    if "final_stage3_score" in candidates_df.columns:
        avg_score = pd.to_numeric(
            candidates_df["final_stage3_score"],
            errors="coerce",
        ).mean()

    metric_col1, metric_col2, metric_col3, metric_col4, metric_col5 = st.columns(5)
    metric_col1.metric("Top 20", top20_count)
    metric_col2.metric("Top 50", top50_count)
    metric_col3.metric("Top 100", top100_count)
    metric_col4.metric("Recuperables", recoverable_count)
    metric_col5.metric("Score medio", f"{avg_score:.2f}" if pd.notna(avg_score) else "—")

    top_row = candidates_df.iloc[0]
    st.success(
        "Mejor candidata Stage 3: "
        f"{top_row.get('ticker', '—')} — "
        f"{top_row.get('name', '—')} — "
        f"{top_row.get('final_stage3_score', '—')} puntos — "
        f"{top_row.get('stage3_category', '—')}"
    )

    if len(candidates_df) <= 5:
        st.warning(
            "Estás viendo una muestra pequeña de candidatos. "
            "Esto parece una validación demo del embudo, no un universo real amplio."
        )

    _sf5g_render_stage3_candidates_cards(candidates_df)

    st.markdown("### Tabla de candidatos")

    display_df = _sf5g_prepare_stage3_display_df(candidates_df)

    category_options = ["Todas"]

    if "Categoría Stage 3" in display_df.columns:
        category_options += sorted(
            [str(value) for value in display_df["Categoría Stage 3"].dropna().unique()]
        )

    selected_category = st.selectbox(
        "Filtrar por categoría",
        options=category_options,
        index=0,
    )

    filtered_df = display_df.copy()

    if selected_category != "Todas" and "Categoría Stage 3" in filtered_df.columns:
        filtered_df = filtered_df[
            filtered_df["Categoría Stage 3"].astype(str) == selected_category
        ]

    st.dataframe(filtered_df, use_container_width=True, hide_index=True)

    csv_bytes = filtered_df.to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        "Descargar candidatos Stage 3",
        data=csv_bytes,
        file_name="stage3_candidates_display.csv",
        mime="text/csv",
        use_container_width=True,
    )

    with st.expander("Distribución por categoría", expanded=False):
        if "stage3_category" in candidates_df.columns:
            category_df = (
                candidates_df["stage3_category"]
                .fillna("Sin categoría")
                .astype(str)
                .value_counts()
                .reset_index()
            )
            category_df.columns = ["Categoría", "Empresas"]
            st.dataframe(category_df, use_container_width=True, hide_index=True)
        else:
            st.info("No hay columna `stage3_category`.")

    with st.expander("Archivos usados por esta pestaña", expanded=False):
        files_df = pd.DataFrame(
            [
                {
                    "archivo": "top_20_deep_research.csv",
                    "ruta": str(scouting_dir / "top_20_deep_research.csv"),
                    "filas": top20_count,
                },
                {
                    "archivo": "top_50_watchlist.csv",
                    "ruta": str(scouting_dir / "top_50_watchlist.csv"),
                    "filas": top50_count,
                },
                {
                    "archivo": "top_100_candidates.csv",
                    "ruta": str(top100_path),
                    "filas": top100_count,
                },
                {
                    "archivo": "top_recoverable_candidates.csv",
                    "ruta": str(scouting_dir / "top_recoverable_candidates.csv"),
                    "filas": recoverable_count,
                },
            ]
        )
        st.dataframe(files_df, use_container_width=True, hide_index=True)

    st.info(
        "Esta vista es solo una conexión visual con el embudo global. "
        "No es una recomendación de inversión y no ejecuta análisis IA."
    )




def _sf5h_read_json(path: Path) -> dict:
    """
    Read JSON safely for funnel summary.
    """

    if not path.exists():
        return {}

    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _sf5h_build_funnel_rows() -> list[dict]:
    """
    Build Stage 0/1/2/3 funnel rows from existing summary JSON files.

    This does not call OpenAI and does not modify outputs.
    """

    scouting_dir = _sf5g_project_root() / "outputs" / "scouting"

    stage0 = _sf5h_read_json(scouting_dir / "universe_validation_summary.json")
    stage1 = _sf5h_read_json(scouting_dir / "stage1_summary.json")
    stage2 = _sf5h_read_json(scouting_dir / "stage2_summary.json")
    stage3 = _sf5h_read_json(scouting_dir / "stage3_summary.json")

    rows = [
        {
            "stage": "Stage 0",
            "nombre": "Universo validado",
            "input": stage0.get("input_companies", 0),
            "passed": stage0.get("input_companies", 0) if stage0.get("status") == "OK" else 0,
            "watchlist": 0,
            "rejected": 0,
            "status": stage0.get("status", "missing") or "missing",
            "summary_file": "universe_validation_summary.json",
        },
        {
            "stage": "Stage 1",
            "nombre": "Investable universe",
            "input": stage1.get("input_companies", 0),
            "passed": stage1.get("passed_companies", 0),
            "watchlist": stage1.get("watchlist_companies", 0),
            "rejected": stage1.get("rejected_companies", 0),
            "status": "OK" if stage1 else "missing",
            "summary_file": "stage1_summary.json",
        },
        {
            "stage": "Stage 2",
            "nombre": "Financial sanity check",
            "input": stage2.get("input_companies", 0),
            "passed": stage2.get("passed_companies", 0),
            "watchlist": stage2.get("watchlist_companies", 0),
            "rejected": stage2.get("rejected_companies", 0),
            "status": "OK" if stage2 else "missing",
            "summary_file": "stage2_summary.json",
        },
        {
            "stage": "Stage 3",
            "nombre": "Opportunity scoring",
            "input": stage3.get("input_companies", 0),
            "passed": stage3.get("passed_companies", 0),
            "watchlist": stage3.get("watchlist_companies", 0),
            "rejected": stage3.get("rejected_companies", 0),
            "status": "OK" if stage3 else "missing",
            "summary_file": "stage3_summary.json",
        },
    ]

    for row in rows:
        input_count = row.get("input") or 0
        passed_count = row.get("passed") or 0
        row["pass_rate"] = round((passed_count / input_count) * 100, 2) if input_count else 0.0

    return rows


def _sf5h_render_funnel_step_card(row: dict) -> None:
    """
    Render one compact funnel stage card.
    """

    status = row.get("status", "missing")
    status_text = "✅ OK" if status == "OK" else "⚠️ Pendiente"

    st.markdown(
        f"""
        <div style="
            border:1px solid #e5e7eb;
            border-radius:14px;
            padding:14px;
            background:#ffffff;
            min-height:150px;
        ">
            <div style="font-size:12px;color:#6b7280;">{row.get('stage')}</div>
            <div style="font-size:17px;font-weight:750;margin-bottom:8px;">{row.get('nombre')}</div>
            <div style="font-size:24px;font-weight:800;">{row.get('passed', 0)}</div>
            <div style="font-size:12px;color:#6b7280;margin-bottom:8px;">pasan / disponibles</div>
            <div style="font-size:12px;color:#374151;">
                Input: {row.get('input', 0)} · Watchlist: {row.get('watchlist', 0)} · Rechazadas: {row.get('rejected', 0)}
            </div>
            <div style="font-size:12px;color:#6b7280;margin-top:8px;">{status_text} · {row.get('pass_rate', 0)}%</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _render_global_funnel_summary_dashboard() -> None:
    """
    Render visual global funnel summary on Dashboard.

    Phase 5H:
    Optional visual summary. Does not call OpenAI and does not modify outputs.
    """

    st.markdown("## 🧭 Embudo global de scouting")
    st.caption(
        "Resumen visual de Stage 0 → Stage 1 → Stage 2 → Stage 3. "
        "No ejecuta OpenAI ni modifica archivos."
    )

    rows = _sf5h_build_funnel_rows()

    if not rows or all((row.get("input", 0) == 0 and row.get("passed", 0) == 0) for row in rows):
        st.info(
            "Aún no hay resúmenes del embudo global. "
            "Ejecuta Fase 5B, 5C, 5D y 5E para generar los JSON de resumen."
        )
        return

    total_stage0 = rows[0].get("input", 0)
    total_stage3 = rows[-1].get("passed", 0) + rows[-1].get("watchlist", 0)

    cols = st.columns(4)

    for idx, row in enumerate(rows):
        with cols[idx]:
            _sf5h_render_funnel_step_card(row)

    if total_stage0 <= 10:
        st.warning(
            "Estás viendo una validación pequeña del embudo. "
            "Cuando cargues el universo real, esta vista mostrará el flujo tipo "
            "59.000 → Stage 1 → Stage 2 → Stage 3 → candidatas finales."
        )
    else:
        st.success(
            f"Embudo procesado: {total_stage0} empresas iniciales → "
            f"{total_stage3} candidatas Stage 3."
        )

    funnel_df = pd.DataFrame(rows)

    display_df = funnel_df.rename(
        columns={
            "stage": "Stage",
            "nombre": "Nombre",
            "input": "Input",
            "passed": "Pasan",
            "watchlist": "Watchlist",
            "rejected": "Rechazadas",
            "pass_rate": "% pasan",
            "status": "Estado",
            "summary_file": "Archivo resumen",
        }
    )

    with st.expander("Ver tabla técnica del embudo", expanded=False):
        st.dataframe(display_df, use_container_width=True, hide_index=True)

    with st.expander("Ver principales motivos de rechazo", expanded=False):
        scouting_dir = _sf5g_project_root() / "outputs" / "scouting"
        reason_rows = []

        for summary_name in ["stage1_summary.json", "stage2_summary.json", "stage3_summary.json"]:
            summary = _sf5h_read_json(scouting_dir / summary_name)
            reasons = summary.get("top_rejection_or_watchlist_reasons", {})

            for reason_code, count in reasons.items():
                reason_rows.append(
                    {
                        "stage": summary.get("stage", summary_name.replace("_summary.json", "")),
                        "reason_code": reason_code,
                        "count": count,
                    }
                )

        if reason_rows:
            reasons_df = pd.DataFrame(reason_rows)
            st.dataframe(reasons_df, use_container_width=True, hide_index=True)
        else:
            st.info("No hay motivos de rechazo/watchlist registrados todavía.")

    st.info(
        "Este bloque resume el embudo automático. "
        "No es recomendación de inversión; solo indica cuántas empresas pasan cada filtro."
    )


def main() -> None:
    """
    Streamlit main entry point.
    """

    _init_session_state()

    if not st.session_state.authenticated:
        _render_login()

    mode, top_n = _render_sidebar()

    if st.session_state.show_faq:
        _render_faq_main()
        return

    st.title("📊 Scout Finance")
    st.caption(
        "Private Research MVP para priorizar empresas investigables. "
        "No es asesoramiento financiero. No se conecta a brokers."
    )

    (
        dashboard_tab,
        ranking_tab,
        company_tab,
        comparison_tab,
        stage3_candidates_tab,
        history_tab,
        settings_tab,
    ) = st.tabs(
        [
            "🏠 Dashboard",
            "🔎 Ranking",
            "📄 Análisis empresa",
            "🧮 Comparar empresas",
            "🧭 Candidatos Stage 3",
            "🧾 Histórico / técnico",
            "⚙️ Ajustes",
        ]
    )

    final_df_for_feedback = pd.DataFrame()

    with dashboard_tab:
        _render_dashboard_tab(mode, top_n)
        st.divider()
        _render_global_funnel_summary_dashboard()

    with ranking_tab:
        final_df_for_feedback = _render_ranking_tab(mode, top_n)

    with company_tab:
        company_df = _render_company_analysis_tab(mode, top_n)

        if final_df_for_feedback.empty and not company_df.empty:
            final_df_for_feedback = company_df

    with comparison_tab:
        _render_phase3b_json_comparison()

    with stage3_candidates_tab:
        _render_stage3_candidates_tab()

    with history_tab:
        _render_history_technical_tab(mode, top_n)

    with settings_tab:
        _render_settings_tab()

    st.divider()

    if final_df_for_feedback.empty:
        final_df_for_feedback = _get_latest_final_view_df(mode=mode, top_n=top_n)

    _render_feedback_form(mode, final_df_for_feedback)


if __name__ == "__main__":
    main()
