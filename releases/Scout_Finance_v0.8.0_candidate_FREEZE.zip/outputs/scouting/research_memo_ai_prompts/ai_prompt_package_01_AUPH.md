# Scout Finance — AI Research Memo Prompt Package

## Ticker
AUPH

## Company
Aurinia Pharmaceuticals Inc - Common Shares

## Phase
8H — Prompt Packaging and Dry-run AI Memo Preview

## Gate
- AI gate status: closed
- AI allowed: False
- OpenAI called: False
- Estimated cost: 0.0
- Model used: null

## System prompt

```text
You are Scout Finance AI Equity Research Memo Assistant. You must not invent data. Separate objective data from interpretation. If data is missing, explicitly mark data_insufficient. Do not provide personalized financial advice. Do not claim real-time market knowledge unless supplied in the input.
```

## User prompt payload

```json
{
  "task": "Create an AI interpretation layer for an equity research memo using only the supplied data.",
  "constraints": [
    "Do not invent facts.",
    "Use only supplied objective_data, scores, sources and data_gaps.",
    "Separate bull_case, base_case, bear_case, final_verdict and confidence.",
    "Mention uncertainty and data gaps clearly.",
    "Return JSON compatible with equity_research_memo_schema_v0_1."
  ],
  "ticker": "AUPH",
  "company_name": "Aurinia Pharmaceuticals Inc - Common Shares",
  "ranking_position": 1,
  "quant_score": 70.83,
  "memo_status": "data_insufficient",
  "scores": {},
  "objective_data": "{\"ticker\": \"AUPH\", \"company_name\": \"Aurinia Pharmaceuticals Inc - Common Shares\", \"ranking_position\": 1, \"quant_score\": 70.83, \"memo_status\": \"data_insufficient\", \"sources\": [{\"type\": \"local_file\", \"path\": \"D:\\\\Proyectos\\\\💰 Scout Finance\\\\outputs\\\\scouting\\\\stage3_candidates_for_ranking.csv\"}], \"business_model\": {\"status\": \"data_insufficient\", \"objective_data\": {}, \"interpretation\": null, \"data_gaps\": [\"Business model requires external/company description data not available in local ranking rows.\"]}, \"financial_health\": {\"ticker\": \"AUPH\", \"module\": \"fundamentals\", \"status\": \"data_insufficient\", \"score\": null, \"objective_data\": {\"revenue_growth\": null, \"gross_margin\": null, \"operating_margin\": null, \"net_margin\": null, \"roe\": null, \"roa\": null, \"debt_to_equity\": null, \"current_ratio\": null, \"free_cash_flow\": null}, \"metric_scores\": {\"revenue_growth\": null, \"gross_margin\": null, \"operating_margin\": null, \"net_margin\": null, \"roe\": null, \"roa\": null, \"debt_to_equity\": null, \"current_ratio\": null, \"free_cash_flow\": null}, \"interpretation\": \"Insufficient objective fundamentals available; no synthetic fundamentals were created.\", \"data_gaps\": [\"revenue_growth\", \"gross_margin\", \"operating_margin\", \"net_margin\", \"roe\", \"roa\", \"debt_to_equity\", \"current_ratio\", \"free_cash_flow\"]}, \"valuation_analysis\": {\"ticker\": \"AUPH\", \"module\": \"valuation\", \"status\": \"data_insufficient\", \"score\": null, \"objective_data\": {\"pe\": null, \"price_to_sales\": null, \"price_to_book\": null, \"ev_to_ebitda\": null, \"fcf_yield\": null, \"quant_score\": 70.83}, \"metric_scores\": {\"pe\": null, \"price_to_sales\": null, \"price_to_book\": null, \"ev_to_ebitda\": null, \"fcf_yield\": null}, \"interpretation\": \"Valuation estimated only from available multiples; absent multiples remain data gaps.\", \"data_gaps\": [\"pe\", \"price_to_sales\", \"price_to_book\", \"ev_to_ebitda\", \"fcf_yield\"]}, \"risk_analysis\": {\"ticker\": \"AUPH\", \"module\": \"risk_analysis\", \"status\": \"data_insufficient\", \"score\": null, \"risk_level\": null, \"objective_data\": {\"beta\": null, \"volatility\": null, \"max_drawdown\": null, \"debt_to_equity\": null, \"short_ratio\": null, \"current_ratio\": null, \"market_cap\": null}, \"metric_scores\": {\"beta\": null, \"volatility\": null, \"max_drawdown\": null, \"debt_to_equity\": null, \"short_ratio\": null, \"current_ratio\": null, \"market_cap\": null}, \"interpretation\": \"Risk score is deterministic and based only on available balance-sheet, liquidity, volatility and size proxies.\", \"data_gaps\": [\"beta\", \"volatility\", \"max_drawdown\", \"debt_to_equity\", \"short_ratio\", \"current_ratio\", \"market_cap\"]}, \"moat_analysis\": {\"ticker\": \"AUPH\", \"module\": \"moat_analysis\", \"status\": \"data_insufficient\", \"score\": null, \"objective_data\": {\"gross_margin\": null, \"operating_margin\": null, \"roe\": null, \"roic\": null, \"revenue_growth\": null}, \"metric_scores\": {\"gross_margin\": null, \"operating_margin\": null, \"roe\": null, \"roic\": null, \"revenue_growth\": null}, \"interpretation\": \"Moat is only a proxy from profitability and return metrics; it is not proof of durable competitive advantage.\", \"data_gaps\": [\"gross_margin\", \"operating_margin\", \"roe\", \"roic\", \"revenue_growth\"]}, \"growth_analysis\": {\"ticker\": \"AUPH\", \"module\": \"growth_analysis\", \"status\": \"data_insufficient\", \"score\": null, \"objective_data\": {\"revenue_growth\": null, \"earnings_growth\": null, \"ebitda_growth\": null, \"free_cash_flow_growth\": null, \"analyst_growth\": null}, \"metric_scores\": {\"revenue_growth\": null, \"earnings_growth\": null, \"ebitda_growth\": null, \"free_cash_flow_growth\": null, \"analyst_growth\": null}, \"interpretation\": \"Growth score is based only on available growth fields in the existing dataset.\", \"data_gaps\": [\"revenue_growth\", \"earnings_growth\", \"ebitda_growth\", \"free_cash_flow_growth\", \"analyst_growth\"]}, \"institutional_view\": {\"ticker\": \"AUPH\", \"module\": \"institutional_view\", \"status\": \"data_insufficient\", \"score\": null, \"objective_data\": {\"institutional_ownership\": null, \"insider_ownership\": null, \"analyst_count\": null, \"recommendation_mean\": null}, \"metric_scores\": {\"institutional_ownership\": null, \"insider_ownership\": null, \"analyst_count\": null, \"recommendation_mean\": null}, \"interpretation\": \"Institutional view is a deterministic proxy from ownership and analyst-coverage fields only.\", \"data_gaps\": [\"institutional_ownership\", \"insider_ownership\", \"analyst_count\", \"recommendation_mean\"]}, \"earnings_analysis\": {\"ticker\": \"AUPH\", \"module\": \"earnings_analysis\", \"status\": \"data_insufficient\", \"score\": null, \"objective_data\": {\"eps_growth\": null, \"revenue_growth\": null, \"earnings_surprise\": null, \"next_earnings_date\": null}, \"metric_scores\": {\"eps_growth\": null, \"revenue_growth\": null, \"earnings_surprise\": null}, \"interpretation\": \"Earnings analysis is deterministic and incomplete when earnings fields are absent.\", \"data_gaps\": [\"eps_growth\", \"revenue_growth\", \"earnings_surprise\", \"next_earnings_date\"]}, \"data_gaps\": [\"financial_health: revenue_growth\", \"financial_health: gross_margin\", \"financial_health: operating_margin\", \"financial_health: net_margin\", \"financial_health: roe\", \"financial_health: roa\", \"financial_health: debt_to_equity\", \"financial_health: current_ratio\", \"financial_health: free_cash_flow\", \"valuation_analysis: pe\", \"valuation_analysis: price_to_sales\", \"valuation_analysis: price_to_book\", \"valuation_analysis: ev_to_ebitda\", \"valuation_analysis: fcf_yield\", \"risk_analysis: beta\", \"risk_analysis: volatility\", \"risk_analysis: max_drawdown\", \"risk_analysis: debt_to_equity\", \"risk_analysis: short_ratio\", \"risk_analysis: current_ratio\", \"risk_analysis: market_cap\", \"moat_analysis: gross_margin\", \"moat_analysis: operating_margin\", \"moat_analysis: roe\", \"moat_analysis: roic\", \"moat_analysis: revenue_growth\", \"growth_analysis: revenue_growth\", \"growth_analysis: earnings_growth\", \"growth_analysis: ebitda_growth\", \"growth_analysis: free_cash_flow_growth\", \"growth_analysis: analyst_growth\", \"institutional_view: institutional_ownership\", \"institutional_view: insider_ownership\", \"institutional_view: analyst_count\", \"institutional_view: recommendation_mean\", \"earnings_analysis: eps_growth\", \"earnings_analysis: revenue_growth\", \"earnings_analysis: earnings_surprise\", \"earnings_analysis: next_earnings_date\", \"business_model: local ranking rows do not provide enough company narrative data.\"]}",
  "data_gaps": "[\"financial_health: revenue_growth\", \"financial_health: gross_margin\", \"financial_health: operating_margin\", \"financial_health: net_margin\", \"financial_health: roe\", \"financial_health: roa\", \"financial_health: debt_to_equity\", \"financial_health: current_ratio\", \"financial_health: free_cash_flow\", \"valuation_analysis: pe\", \"valuation_analysis: price_to_sales\", \"valuation_analysis: price_to_book\", \"valuation_analysis: ev_to_ebitda\", \"valuation_analysis: fcf_yield\", \"risk_analysis: beta\", \"risk_analysis: volatility\", \"risk_analysis: max_drawdown\", \"risk_analysis: debt_to_equity\", \"risk_analysis: short_ratio\", \"risk_analysis: current_ratio\", \"risk_analysis: market_cap\", \"moat_analysis: gross_margin\", \"moat_analysis: operating_margin\", \"moat_analysis: roe\", \"moat_analysis: roic\", \"moat_analysis: revenue_growth\", \"growth_analysis: revenue_growth\", \"growth_analysis: earnings_growth\", \"growth_analysis: ebitda_growth\", \"growth_analysis: free_cash_flow_growth\", \"growth_analysis: analyst_growth\", \"institutional_view: institutional_ownership\", \"institutional_view: insider_ownership\", \"institutional_view: analyst_count\", \"institutional_view: recommendation_mean\", \"earnings_analysis: eps_growth\", \"earnings_analysis: revenue_growth\", \"earnings_analysis: earnings_surprise\", \"earnings_analysis: next_earnings_date\", \"business_model: local ranking rows do not provide enough company narrative data.\"]",
  "sources": []
}
```

## Dry-run preview

```json
{
  "ticker": "AUPH",
  "company_name": "Aurinia Pharmaceuticals Inc - Common Shares",
  "ai_interpretation_status": "dry_run_only",
  "openai_called": false,
  "estimated_cost": 0.0,
  "model_used": null,
  "preview_sections": {
    "bull_case": "DRY RUN PLACEHOLDER — would be generated only if AI gate is open.",
    "base_case": "DRY RUN PLACEHOLDER — would be generated only if AI gate is open.",
    "bear_case": "DRY RUN PLACEHOLDER — would be generated only if AI gate is open.",
    "final_verdict": "DRY RUN PLACEHOLDER — no investment recommendation generated.",
    "confidence": "data_insufficient"
  },
  "data_gaps": "[\"financial_health: revenue_growth\", \"financial_health: gross_margin\", \"financial_health: operating_margin\", \"financial_health: net_margin\", \"financial_health: roe\", \"financial_health: roa\", \"financial_health: debt_to_equity\", \"financial_health: current_ratio\", \"financial_health: free_cash_flow\", \"valuation_analysis: pe\", \"valuation_analysis: price_to_sales\", \"valuation_analysis: price_to_book\", \"valuation_analysis: ev_to_ebitda\", \"valuation_analysis: fcf_yield\", \"risk_analysis: beta\", \"risk_analysis: volatility\", \"risk_analysis: max_drawdown\", \"risk_analysis: debt_to_equity\", \"risk_analysis: short_ratio\", \"risk_analysis: current_ratio\", \"risk_analysis: market_cap\", \"moat_analysis: gross_margin\", \"moat_analysis: operating_margin\", \"moat_analysis: roe\", \"moat_analysis: roic\", \"moat_analysis: revenue_growth\", \"growth_analysis: revenue_growth\", \"growth_analysis: earnings_growth\", \"growth_analysis: ebitda_growth\", \"growth_analysis: free_cash_flow_growth\", \"growth_analysis: analyst_growth\", \"institutional_view: institutional_ownership\", \"institutional_view: insider_ownership\", \"institutional_view: analyst_count\", \"institutional_view: recommendation_mean\", \"earnings_analysis: eps_growth\", \"earnings_analysis: revenue_growth\", \"earnings_analysis: earnings_surprise\", \"earnings_analysis: next_earnings_date\", \"business_model: local ranking rows do not provide enough company narrative data.\"]"
}
```

## Safety notes

- No inventar datos.
- data_insufficient debe mantenerse cuando falten datos.
- Objective data and AI interpretation remain separated.
- This file is a dry-run package only; no API/OpenAI call was made.
